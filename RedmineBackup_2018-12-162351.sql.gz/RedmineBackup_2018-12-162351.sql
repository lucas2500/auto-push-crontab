-- MySQL dump 10.13  Distrib 5.7.24, for Linux (x86_64)
--
-- Host: localhost    Database: redmine
-- ------------------------------------------------------
-- Server version	5.7.24-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `agile_colors`
--

DROP TABLE IF EXISTS `agile_colors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agile_colors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `container_id` int(11) DEFAULT NULL,
  `container_type` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_agile_colors_on_container_id` (`container_id`),
  KEY `index_agile_colors_on_container_type` (`container_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agile_colors`
--

LOCK TABLES `agile_colors` WRITE;
/*!40000 ALTER TABLE `agile_colors` DISABLE KEYS */;
/*!40000 ALTER TABLE `agile_colors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agile_data`
--

DROP TABLE IF EXISTS `agile_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agile_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `issue_id` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `story_points` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_agile_data_on_issue_id` (`issue_id`),
  KEY `index_agile_data_on_position` (`position`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agile_data`
--

LOCK TABLES `agile_data` WRITE;
/*!40000 ALTER TABLE `agile_data` DISABLE KEYS */;
INSERT INTO `agile_data` VALUES (1,6,4,NULL),(2,4,0,NULL),(3,1,1,NULL),(5,10,5,NULL),(6,11,0,NULL),(7,13,4,NULL),(8,12,6,NULL),(11,28,NULL,NULL),(12,18,NULL,NULL),(13,17,NULL,NULL),(14,19,NULL,NULL),(15,20,NULL,NULL),(16,21,NULL,NULL),(17,22,NULL,NULL),(18,24,NULL,NULL),(19,25,NULL,NULL),(20,26,NULL,NULL),(21,27,NULL,NULL),(22,30,NULL,NULL),(23,31,NULL,NULL),(24,32,NULL,NULL),(25,33,NULL,NULL),(26,34,NULL,NULL),(27,35,NULL,NULL),(28,36,NULL,NULL),(29,37,NULL,NULL),(30,38,NULL,NULL),(31,39,NULL,NULL),(32,40,NULL,NULL),(33,41,NULL,NULL),(34,42,NULL,NULL),(35,43,NULL,NULL),(36,44,NULL,NULL),(37,45,NULL,NULL),(38,46,NULL,NULL),(39,47,NULL,NULL),(40,49,NULL,NULL),(41,50,NULL,NULL),(58,79,NULL,NULL),(59,80,NULL,NULL),(60,78,NULL,NULL),(61,83,NULL,NULL),(62,82,NULL,NULL),(63,81,NULL,NULL),(64,85,NULL,NULL),(82,112,5,NULL),(83,111,16,NULL),(84,113,0,NULL),(85,114,0,NULL),(86,115,4,NULL),(87,116,4,NULL),(88,117,3,NULL),(89,119,6,NULL),(90,120,7,NULL),(91,121,1,NULL),(92,122,0,NULL),(93,123,2,NULL),(94,125,2,NULL),(95,128,0,NULL),(96,129,1,NULL),(97,126,1,NULL),(98,127,1,NULL);
/*!40000 ALTER TABLE `agile_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attachments`
--

DROP TABLE IF EXISTS `attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `container_id` int(11) DEFAULT NULL,
  `container_type` varchar(30) DEFAULT NULL,
  `filename` varchar(255) NOT NULL DEFAULT '',
  `disk_filename` varchar(255) NOT NULL DEFAULT '',
  `filesize` bigint(20) NOT NULL DEFAULT '0',
  `content_type` varchar(255) DEFAULT '',
  `digest` varchar(40) NOT NULL DEFAULT '',
  `downloads` int(11) NOT NULL DEFAULT '0',
  `author_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `disk_directory` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_attachments_on_author_id` (`author_id`),
  KEY `index_attachments_on_created_on` (`created_on`),
  KEY `index_attachments_on_container_id_and_container_type` (`container_id`,`container_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachments`
--

LOCK TABLES `attachments` WRITE;
/*!40000 ALTER TABLE `attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_sources`
--

DROP TABLE IF EXISTS `auth_sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(30) NOT NULL DEFAULT '',
  `name` varchar(60) NOT NULL DEFAULT '',
  `host` varchar(60) DEFAULT NULL,
  `port` int(11) DEFAULT NULL,
  `account` varchar(255) DEFAULT NULL,
  `account_password` varchar(255) DEFAULT '',
  `base_dn` varchar(255) DEFAULT NULL,
  `attr_login` varchar(30) DEFAULT NULL,
  `attr_firstname` varchar(30) DEFAULT NULL,
  `attr_lastname` varchar(30) DEFAULT NULL,
  `attr_mail` varchar(30) DEFAULT NULL,
  `onthefly_register` tinyint(1) NOT NULL DEFAULT '0',
  `tls` tinyint(1) NOT NULL DEFAULT '0',
  `filter` text,
  `timeout` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_auth_sources_on_id_and_type` (`id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_sources`
--

LOCK TABLES `auth_sources` WRITE;
/*!40000 ALTER TABLE `auth_sources` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_sources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `boards`
--

DROP TABLE IF EXISTS `boards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `boards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `topics_count` int(11) NOT NULL DEFAULT '0',
  `messages_count` int(11) NOT NULL DEFAULT '0',
  `last_message_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `boards_project_id` (`project_id`),
  KEY `index_boards_on_last_message_id` (`last_message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `boards`
--

LOCK TABLES `boards` WRITE;
/*!40000 ALTER TABLE `boards` DISABLE KEYS */;
/*!40000 ALTER TABLE `boards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changes`
--

DROP TABLE IF EXISTS `changes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changeset_id` int(11) NOT NULL,
  `action` varchar(1) NOT NULL DEFAULT '',
  `path` text NOT NULL,
  `from_path` text,
  `from_revision` varchar(255) DEFAULT NULL,
  `revision` varchar(255) DEFAULT NULL,
  `branch` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `changesets_changeset_id` (`changeset_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changes`
--

LOCK TABLES `changes` WRITE;
/*!40000 ALTER TABLE `changes` DISABLE KEYS */;
/*!40000 ALTER TABLE `changes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changeset_parents`
--

DROP TABLE IF EXISTS `changeset_parents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changeset_parents` (
  `changeset_id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  KEY `changeset_parents_changeset_ids` (`changeset_id`),
  KEY `changeset_parents_parent_ids` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changeset_parents`
--

LOCK TABLES `changeset_parents` WRITE;
/*!40000 ALTER TABLE `changeset_parents` DISABLE KEYS */;
/*!40000 ALTER TABLE `changeset_parents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changesets`
--

DROP TABLE IF EXISTS `changesets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changesets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `repository_id` int(11) NOT NULL,
  `revision` varchar(255) NOT NULL,
  `committer` varchar(255) DEFAULT NULL,
  `committed_on` datetime NOT NULL,
  `comments` longtext,
  `commit_date` date DEFAULT NULL,
  `scmid` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `changesets_repos_rev` (`repository_id`,`revision`),
  KEY `index_changesets_on_user_id` (`user_id`),
  KEY `index_changesets_on_repository_id` (`repository_id`),
  KEY `index_changesets_on_committed_on` (`committed_on`),
  KEY `changesets_repos_scmid` (`repository_id`,`scmid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changesets`
--

LOCK TABLES `changesets` WRITE;
/*!40000 ALTER TABLE `changesets` DISABLE KEYS */;
/*!40000 ALTER TABLE `changesets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changesets_issues`
--

DROP TABLE IF EXISTS `changesets_issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changesets_issues` (
  `changeset_id` int(11) NOT NULL,
  `issue_id` int(11) NOT NULL,
  UNIQUE KEY `changesets_issues_ids` (`changeset_id`,`issue_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changesets_issues`
--

LOCK TABLES `changesets_issues` WRITE;
/*!40000 ALTER TABLE `changesets_issues` DISABLE KEYS */;
/*!40000 ALTER TABLE `changesets_issues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `commented_type` varchar(30) NOT NULL DEFAULT '',
  `commented_id` int(11) NOT NULL DEFAULT '0',
  `author_id` int(11) NOT NULL DEFAULT '0',
  `comments` text,
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_comments_on_commented_id_and_commented_type` (`commented_id`,`commented_type`),
  KEY `index_comments_on_author_id` (`author_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_field_enumerations`
--

DROP TABLE IF EXISTS `custom_field_enumerations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_field_enumerations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `custom_field_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `position` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_field_enumerations`
--

LOCK TABLES `custom_field_enumerations` WRITE;
/*!40000 ALTER TABLE `custom_field_enumerations` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_field_enumerations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_fields`
--

DROP TABLE IF EXISTS `custom_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(30) NOT NULL DEFAULT '',
  `name` varchar(30) NOT NULL DEFAULT '',
  `field_format` varchar(30) NOT NULL DEFAULT '',
  `possible_values` text,
  `regexp` varchar(255) DEFAULT '',
  `min_length` int(11) DEFAULT NULL,
  `max_length` int(11) DEFAULT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT '0',
  `is_for_all` tinyint(1) NOT NULL DEFAULT '0',
  `is_filter` tinyint(1) NOT NULL DEFAULT '0',
  `position` int(11) DEFAULT NULL,
  `searchable` tinyint(1) DEFAULT '0',
  `default_value` text,
  `editable` tinyint(1) DEFAULT '1',
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `multiple` tinyint(1) DEFAULT '0',
  `format_store` text,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `index_custom_fields_on_id_and_type` (`id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_fields`
--

LOCK TABLES `custom_fields` WRITE;
/*!40000 ALTER TABLE `custom_fields` DISABLE KEYS */;
INSERT INTO `custom_fields` VALUES (1,'ProjectCustomField','Sponsor ','string',NULL,'',NULL,NULL,1,0,1,1,1,'',1,1,0,'--- !ruby/hash:ActiveSupport::HashWithIndifferentAccess\ntext_formatting: \'\'\nurl_pattern: \'\'\n',''),(3,'UserCustomField','Área','string',NULL,'',NULL,NULL,1,0,1,1,0,'',1,1,0,'--- !ruby/hash:ActiveSupport::HashWithIndifferentAccess\ntext_formatting: \'\'\nurl_pattern: \'\'\n',''),(8,'ProjectCustomField','Dono(a)','list','---\n- KAROLINA BENIZ\n- HERBERT AYRES\n','',NULL,NULL,1,0,1,2,1,'',1,1,0,'--- !ruby/hash:ActiveSupport::HashWithIndifferentAccess\nurl_pattern: \'\'\nedit_tag_style: \'\'\n',''),(9,'ProjectCustomField','Inicio do projeto','date',NULL,'',NULL,NULL,1,0,1,3,0,'',1,1,0,'--- !ruby/hash:ActiveSupport::HashWithIndifferentAccess\nurl_pattern: \'\'\n','');
/*!40000 ALTER TABLE `custom_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_fields_projects`
--

DROP TABLE IF EXISTS `custom_fields_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_fields_projects` (
  `custom_field_id` int(11) NOT NULL DEFAULT '0',
  `project_id` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `index_custom_fields_projects_on_custom_field_id_and_project_id` (`custom_field_id`,`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_fields_projects`
--

LOCK TABLES `custom_fields_projects` WRITE;
/*!40000 ALTER TABLE `custom_fields_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_fields_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_fields_roles`
--

DROP TABLE IF EXISTS `custom_fields_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_fields_roles` (
  `custom_field_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  UNIQUE KEY `custom_fields_roles_ids` (`custom_field_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_fields_roles`
--

LOCK TABLES `custom_fields_roles` WRITE;
/*!40000 ALTER TABLE `custom_fields_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_fields_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_fields_trackers`
--

DROP TABLE IF EXISTS `custom_fields_trackers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_fields_trackers` (
  `custom_field_id` int(11) NOT NULL DEFAULT '0',
  `tracker_id` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `index_custom_fields_trackers_on_custom_field_id_and_tracker_id` (`custom_field_id`,`tracker_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_fields_trackers`
--

LOCK TABLES `custom_fields_trackers` WRITE;
/*!40000 ALTER TABLE `custom_fields_trackers` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_fields_trackers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_values`
--

DROP TABLE IF EXISTS `custom_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customized_type` varchar(30) NOT NULL DEFAULT '',
  `customized_id` int(11) NOT NULL DEFAULT '0',
  `custom_field_id` int(11) NOT NULL DEFAULT '0',
  `value` text,
  PRIMARY KEY (`id`),
  KEY `custom_values_customized` (`customized_type`,`customized_id`),
  KEY `index_custom_values_on_custom_field_id` (`custom_field_id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_values`
--

LOCK TABLES `custom_values` WRITE;
/*!40000 ALTER TABLE `custom_values` DISABLE KEYS */;
INSERT INTO `custom_values` VALUES (1,'Project',1,1,'Aline Sueth'),(3,'Project',2,1,'Lucas Rafael'),(5,'Principal',6,3,'TI'),(10,'Principal',7,3,'TI'),(11,'Principal',8,3,'Jovem Talento TI'),(12,'Principal',9,3,'TI'),(13,'Principal',10,3,'TI'),(14,'Principal',11,3,'TI'),(15,'Project',3,1,'Aline Sueth'),(19,'Principal',13,3,'TI'),(20,'Principal',5,3,'TI'),(21,'Project',2,8,'HERBERT AYRES'),(22,'Project',2,9,'2018-08-03'),(47,'Project',4,1,'Aline Sueth'),(48,'Project',4,8,'KAROLINA BENIZ'),(49,'Project',4,9,'2018-08-20'),(63,'Project',1,8,'HERBERT AYRES'),(64,'Project',1,9,'2018-02-02'),(86,'Project',5,1,'Aline Sueth'),(87,'Project',5,8,'HERBERT AYRES'),(88,'Project',5,9,'2018-08-20');
/*!40000 ALTER TABLE `custom_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rgt` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `background` text,
  `head_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_departments_on_parent_id_and_lft_and_rgt` (`parent_id`,`lft`,`rgt`),
  KEY `index_departments_on_head_id` (`head_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `category_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documents_project_id` (`project_id`),
  KEY `index_documents_on_category_id` (`category_id`),
  KEY `index_documents_on_created_on` (`created_on`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `easy_entity_assignments`
--

DROP TABLE IF EXISTS `easy_entity_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `easy_entity_assignments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entity_from_id` int(11) DEFAULT NULL,
  `entity_from_type` varchar(255) DEFAULT NULL,
  `entity_to_id` int(11) DEFAULT NULL,
  `entity_to_type` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entity_assignment_idx` (`entity_from_type`,`entity_from_id`,`entity_to_type`,`entity_to_id`),
  KEY `entity_assignment_idx_from` (`entity_from_id`),
  KEY `entity_assignment_idx_to` (`entity_to_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `easy_entity_assignments`
--

LOCK TABLES `easy_entity_assignments` WRITE;
/*!40000 ALTER TABLE `easy_entity_assignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `easy_entity_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `easy_settings`
--

DROP TABLE IF EXISTS `easy_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `easy_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `value` text,
  `project_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_easy_settings_on_name_and_project_id` (`name`,`project_id`),
  KEY `index_easy_settings_on_project_id` (`project_id`),
  CONSTRAINT `fk_rails_31c4b01147` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `easy_settings`
--

LOCK TABLES `easy_settings` WRITE;
/*!40000 ALTER TABLE `easy_settings` DISABLE KEYS */;
INSERT INTO `easy_settings` VALUES (1,NULL,'easy_wbs_layout','---\ni31:\n  rank: \'1\'\ni34:\n  rank: \'2\'\ni35:\n  rank: \'3\'\ni36:\n  rank: \'4\'\ni37:\n  rank: \'5\'\ni38:\n  rank: \'6\'\ni39:\n  rank: \'7\'\ni40:\n  rank: \'8\'\ni41:\n  rank: \'9\'\ni42:\n  rank: \'10\'\ni43:\n  rank: \'11\'\ni44:\n  rank: \'12\'\ni45:\n  rank: \'13\'\ni46:\n  rank: \'14\'\ni47:\n  rank: \'15\'\ni29:\n  rank: \"-2\"\ni18:\n  rank: \'1\'\ni19:\n  rank: \'2\'\ni20:\n  rank: \'3\'\ni21:\n  rank: \'4\'\ni22:\n  rank: \'5\'\ni17:\n  rank: \"-1\"\ni4:\n  rank: \'1\'\ni6:\n  rank: \'2\'\ni10:\n  rank: \'3\'\ni11:\n  rank: \'4\'\ni13:\n  rank: \'5\'\ni12:\n  rank: \'6\'\ni1:\n  rank: \'1\'\ni24:\n  rank: \'1\'\ni25:\n  rank: \'2\'\ni26:\n  rank: \'3\'\ni27:\n  rank: \'4\'\ni28:\n  rank: \'5\'\ni23:\n  rank: \'2\'\ni49:\n  rank: \'1\'\ni50:\n  rank: \'2\'\ni48:\n  rank: \'3\'\n',1),(2,NULL,'easy_wbs_layout','---\ni82:\n  rank: \'1\'\ni83:\n  rank: \'2\'\ni84:\n  rank: \'3\'\ni81:\n  rank: \"-1\"\ni79:\n  rank: \'1\'\ni80:\n  rank: \'2\'\n  position:\n  - \'174\'\n  - \'102.96875\'\n  - \'2\'\ni78:\n  rank: \'1\'\n  position:\n  - \'254.8569533817705\'\n  - \"-52.15625\"\n  - \'3\'\ni85:\n  rank: \'2\'\n  position:\n  - \'180.8569533817705\'\n  - \'133.828125\'\n  - \'4\'\n',2),(3,NULL,'easy_wbs_layout','---\ni94:\n  rank: \'1\'\ni95:\n  rank: \'2\'\ni96:\n  rank: \'3\'\ni97:\n  rank: \'4\'\ni98:\n  rank: \'5\'\ni93:\n  rank: \'1\'\n',4),(4,NULL,'easy_wbs_layout','---\ni104:\n  rank: \'1\'\ni105:\n  rank: \'2\'\ni106:\n  rank: \'3\'\ni103:\n  rank: \"-1\"\ni100:\n  rank: \'1\'\ni101:\n  rank: \'2\'\ni102:\n  rank: \'3\'\ni99:\n  rank: \'1\'\ni108:\n  rank: \'1\'\ni109:\n  rank: \'2\'\ni110:\n  rank: \'3\'\ni107:\n  rank: \'2\'\n',5);
/*!40000 ALTER TABLE `easy_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_addresses`
--

DROP TABLE IF EXISTS `email_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_addresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `notify` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_email_addresses_on_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_addresses`
--

LOCK TABLES `email_addresses` WRITE;
/*!40000 ALTER TABLE `email_addresses` DISABLE KEYS */;
INSERT INTO `email_addresses` VALUES (1,1,'admin@example.net',1,1,'2018-08-09 14:32:29','2018-08-09 14:32:29'),(2,5,'lucas.barbosa@grupoelfa.com.br',1,1,'2018-08-09 14:49:46','2018-08-09 14:49:46'),(3,6,'thiago.santos@grupoelfa.com.br',1,1,'2018-08-14 09:05:35','2018-08-14 09:05:35'),(4,7,'herbert.ayres@grupoelfa.com.br',1,1,'2018-08-14 13:14:49','2018-08-14 13:14:49'),(5,8,'clauber.maia@grupoelfa.com.br',1,1,'2018-08-14 13:15:45','2018-08-14 13:15:45'),(6,9,'mayara.guedes@grupoelfa.com.br',1,1,'2018-08-14 13:16:33','2018-08-14 13:16:33'),(7,10,'rodrigo.sobral@grupoelfa.com.br',1,1,'2018-08-14 13:17:09','2018-08-14 13:17:09'),(8,11,'marcelo.miranda@grupoelfa.com.br',1,1,'2018-08-14 13:17:39','2018-08-14 13:17:39'),(9,13,'luana.alves@grupoelfa.com.br',1,1,'2018-08-17 08:12:44','2018-08-17 08:12:44');
/*!40000 ALTER TABLE `email_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enabled_modules`
--

DROP TABLE IF EXISTS `enabled_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enabled_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `enabled_modules_project_id` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enabled_modules`
--

LOCK TABLES `enabled_modules` WRITE;
/*!40000 ALTER TABLE `enabled_modules` DISABLE KEYS */;
INSERT INTO `enabled_modules` VALUES (1,1,'issue_tracking'),(2,1,'time_tracking'),(4,1,'documents'),(5,1,'files'),(9,1,'calendar'),(10,1,'gantt'),(11,1,'easy_wbs'),(12,1,'agile'),(13,1,'easy_gantt'),(14,2,'issue_tracking'),(15,2,'time_tracking'),(16,2,'files'),(17,2,'calendar'),(18,2,'agile'),(19,2,'easy_gantt'),(20,2,'easy_wbs'),(21,3,'issue_tracking'),(22,3,'time_tracking'),(23,3,'news'),(24,3,'documents'),(25,3,'files'),(26,3,'wiki'),(27,3,'repository'),(28,3,'boards'),(29,3,'calendar'),(30,3,'gantt'),(31,4,'issue_tracking'),(32,4,'time_tracking'),(34,4,'documents'),(35,4,'files'),(36,4,'boards'),(37,4,'calendar'),(39,4,'easy_wbs'),(40,4,'agile'),(41,4,'easy_gantt'),(43,5,'issue_tracking'),(44,5,'time_tracking'),(45,5,'news'),(46,5,'documents'),(47,5,'files'),(48,5,'boards'),(49,5,'calendar'),(51,5,'easy_wbs'),(52,5,'agile'),(53,5,'easy_gantt');
/*!40000 ALTER TABLE `enabled_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enumerations`
--

DROP TABLE IF EXISTS `enumerations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enumerations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `position` int(11) DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `type` varchar(255) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `project_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `position_name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_enumerations_on_project_id` (`project_id`),
  KEY `index_enumerations_on_id_and_type` (`id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enumerations`
--

LOCK TABLES `enumerations` WRITE;
/*!40000 ALTER TABLE `enumerations` DISABLE KEYS */;
INSERT INTO `enumerations` VALUES (1,'Baixa',1,0,'IssuePriority',1,NULL,NULL,'lowest'),(2,'Normal',2,1,'IssuePriority',1,NULL,NULL,'default'),(3,'Alta',3,0,'IssuePriority',1,NULL,NULL,'high3'),(4,'Urgente',4,0,'IssuePriority',1,NULL,NULL,'high2'),(5,'Imediata',5,0,'IssuePriority',1,NULL,NULL,'highest'),(6,'Documentação de usuário',1,0,'DocumentCategory',1,NULL,NULL,NULL),(7,'Documentação técnica',2,0,'DocumentCategory',1,NULL,NULL,NULL),(8,'Planejamento',1,0,'TimeEntryActivity',1,NULL,NULL,NULL),(9,'Desenvolvimento',2,0,'TimeEntryActivity',1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `enumerations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gamification_badges`
--

DROP TABLE IF EXISTS `gamification_badges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gamification_badges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `lvl5_badge` int(11) DEFAULT '0',
  `lvl10_badge` int(11) DEFAULT '0',
  `lvl50_badge` int(11) DEFAULT '0',
  `lvl100_badge` int(11) DEFAULT '0',
  `tkt10_badge` int(11) DEFAULT '0',
  `tkt50_badge` int(11) DEFAULT '0',
  `tkt100_badge` int(11) DEFAULT '0',
  `tkt500_badge` int(11) DEFAULT '0',
  `tkt1000_badge` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gamification_badges`
--

LOCK TABLES `gamification_badges` WRITE;
/*!40000 ALTER TABLE `gamification_badges` DISABLE KEYS */;
INSERT INTO `gamification_badges` VALUES (1,1,0,0,0,0,0,0,0,0,0),(2,5,0,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `gamification_badges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gamification_medal_assignments`
--

DROP TABLE IF EXISTS `gamification_medal_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gamification_medal_assignments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `medal_id` int(11) DEFAULT NULL,
  `user_orig_id` int(11) DEFAULT NULL,
  `user_assign_id` int(11) DEFAULT NULL,
  `assign_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_gamification_medal_assignments_on_medal_id` (`medal_id`),
  KEY `index_gamification_medal_assignments_on_user_assign_id` (`user_assign_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gamification_medal_assignments`
--

LOCK TABLES `gamification_medal_assignments` WRITE;
/*!40000 ALTER TABLE `gamification_medal_assignments` DISABLE KEYS */;
INSERT INTO `gamification_medal_assignments` VALUES (1,1,5,1,'2018-08-10 12:49:22');
/*!40000 ALTER TABLE `gamification_medal_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gamification_medal_types`
--

DROP TABLE IF EXISTS `gamification_medal_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gamification_medal_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `image` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gamification_medal_types`
--

LOCK TABLES `gamification_medal_types` WRITE;
/*!40000 ALTER TABLE `gamification_medal_types` DISABLE KEYS */;
INSERT INTO `gamification_medal_types` VALUES (1,'Thanks',NULL),(2,'Smile',NULL),(3,'Nice Job',NULL),(4,'Passion',NULL);
/*!40000 ALTER TABLE `gamification_medal_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gamification_medals`
--

DROP TABLE IF EXISTS `gamification_medals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gamification_medals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `thank_medal` int(11) DEFAULT '0',
  `smile_medal` int(11) DEFAULT '0',
  `nice_medal` int(11) DEFAULT '0',
  `hot_medal` int(11) DEFAULT '0',
  `comm_medal` int(11) DEFAULT '0',
  `grow_medal` int(11) DEFAULT '0',
  `monthly_thank_medal` int(11) DEFAULT '0',
  `monthly_smile_medal` int(11) DEFAULT '0',
  `monthly_nice_medal` int(11) DEFAULT '0',
  `monthly_hot_medal` int(11) DEFAULT '0',
  `monthly_comm_medal` int(11) DEFAULT '0',
  `monthly_grow_medal` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gamification_medals`
--

LOCK TABLES `gamification_medals` WRITE;
/*!40000 ALTER TABLE `gamification_medals` DISABLE KEYS */;
/*!40000 ALTER TABLE `gamification_medals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gamification_projects`
--

DROP TABLE IF EXISTS `gamification_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gamification_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `point` int(11) DEFAULT '0',
  `ticket_count` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gamification_projects`
--

LOCK TABLES `gamification_projects` WRITE;
/*!40000 ALTER TABLE `gamification_projects` DISABLE KEYS */;
INSERT INTO `gamification_projects` VALUES (1,5,1,0,0);
/*!40000 ALTER TABLE `gamification_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gamification_tuts`
--

DROP TABLE IF EXISTS `gamification_tuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gamification_tuts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `desc` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gamification_tuts`
--

LOCK TABLES `gamification_tuts` WRITE;
/*!40000 ALTER TABLE `gamification_tuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `gamification_tuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gamification_user_tuts`
--

DROP TABLE IF EXISTS `gamification_user_tuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gamification_user_tuts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `tut1_f` int(11) DEFAULT '0',
  `tut2_f` int(11) DEFAULT '0',
  `tut3_f` int(11) DEFAULT '0',
  `tut4_f` int(11) DEFAULT '0',
  `tut5_f` int(11) DEFAULT '0',
  `tut6_f` int(11) DEFAULT '0',
  `tut7_f` int(11) DEFAULT '0',
  `tut8_f` int(11) DEFAULT '0',
  `tut9_f` int(11) DEFAULT '0',
  `tut10_f` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gamification_user_tuts`
--

LOCK TABLES `gamification_user_tuts` WRITE;
/*!40000 ALTER TABLE `gamification_user_tuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `gamification_user_tuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gamifications`
--

DROP TABLE IF EXISTS `gamifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gamifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `point` int(11) DEFAULT '0',
  `level` int(11) DEFAULT '1',
  `ticket_count` int(11) DEFAULT '0',
  `image` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gamifications`
--

LOCK TABLES `gamifications` WRITE;
/*!40000 ALTER TABLE `gamifications` DISABLE KEYS */;
INSERT INTO `gamifications` VALUES (1,1,0,1,0,NULL),(2,5,0,1,0,NULL);
/*!40000 ALTER TABLE `gamifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups_users`
--

DROP TABLE IF EXISTS `groups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups_users` (
  `group_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  UNIQUE KEY `groups_users_ids` (`group_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups_users`
--

LOCK TABLES `groups_users` WRITE;
/*!40000 ALTER TABLE `groups_users` DISABLE KEYS */;
INSERT INTO `groups_users` VALUES (12,6);
/*!40000 ALTER TABLE `groups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `holidays`
--

DROP TABLE IF EXISTS `holidays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `holidays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `start` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `holidays`
--

LOCK TABLES `holidays` WRITE;
/*!40000 ALTER TABLE `holidays` DISABLE KEYS */;
/*!40000 ALTER TABLE `holidays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `import_items`
--

DROP TABLE IF EXISTS `import_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `import_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `import_id` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `obj_id` int(11) DEFAULT NULL,
  `message` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `import_items`
--

LOCK TABLES `import_items` WRITE;
/*!40000 ALTER TABLE `import_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `import_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imports`
--

DROP TABLE IF EXISTS `imports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `settings` text,
  `total_items` int(11) DEFAULT NULL,
  `finished` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imports`
--

LOCK TABLES `imports` WRITE;
/*!40000 ALTER TABLE `imports` DISABLE KEYS */;
INSERT INTO `imports` VALUES (1,'IssueImport',1,'bf5bc5a07ad12c69582f61504b65298e','---\nseparator: \";\"\nwrapper: \"\\\"\"\nencoding: ISO-8859-1\ndate_format: \"%d/%m/%Y\"\n',NULL,0,'2018-08-10 10:21:38','2018-08-10 10:21:38'),(2,'IssueImport',1,'25ddd413f19e45a0976496013ae00f13','---\nseparator: \";\"\nwrapper: \"\\\"\"\nencoding: ISO-8859-1\ndate_format: \"%d/%m/%Y\"\n',NULL,0,'2018-08-20 09:06:58','2018-08-20 09:06:58');
/*!40000 ALTER TABLE `imports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issue_categories`
--

DROP TABLE IF EXISTS `issue_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `issue_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(60) NOT NULL DEFAULT '',
  `assigned_to_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `issue_categories_project_id` (`project_id`),
  KEY `index_issue_categories_on_assigned_to_id` (`assigned_to_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issue_categories`
--

LOCK TABLES `issue_categories` WRITE;
/*!40000 ALTER TABLE `issue_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `issue_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issue_relations`
--

DROP TABLE IF EXISTS `issue_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `issue_relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `issue_from_id` int(11) NOT NULL,
  `issue_to_id` int(11) NOT NULL,
  `relation_type` varchar(255) NOT NULL DEFAULT '',
  `delay` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_issue_relations_on_issue_from_id_and_issue_to_id` (`issue_from_id`,`issue_to_id`),
  KEY `index_issue_relations_on_issue_from_id` (`issue_from_id`),
  KEY `index_issue_relations_on_issue_to_id` (`issue_to_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issue_relations`
--

LOCK TABLES `issue_relations` WRITE;
/*!40000 ALTER TABLE `issue_relations` DISABLE KEYS */;
INSERT INTO `issue_relations` VALUES (23,79,80,'precedes',0),(24,80,82,'precedes',0),(25,82,83,'precedes',0),(26,83,84,'precedes',0),(27,84,85,'precedes',0);
/*!40000 ALTER TABLE `issue_relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issue_statuses`
--

DROP TABLE IF EXISTS `issue_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `issue_statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `is_closed` tinyint(1) NOT NULL DEFAULT '0',
  `position` int(11) DEFAULT NULL,
  `default_done_ratio` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_issue_statuses_on_position` (`position`),
  KEY `index_issue_statuses_on_is_closed` (`is_closed`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issue_statuses`
--

LOCK TABLES `issue_statuses` WRITE;
/*!40000 ALTER TABLE `issue_statuses` DISABLE KEYS */;
INSERT INTO `issue_statuses` VALUES (1,'Não iniciada',0,1,NULL),(2,'Em andamento',0,2,NULL),(3,'Concluída',0,3,NULL),(4,'Início atrasado ',0,4,NULL),(5,'Conclusão atrasada',1,5,NULL),(6,'Falta previsão',1,6,NULL);
/*!40000 ALTER TABLE `issue_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issues`
--

DROP TABLE IF EXISTS `issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `issues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tracker_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `due_date` date DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `status_id` int(11) NOT NULL,
  `assigned_to_id` int(11) DEFAULT NULL,
  `priority_id` int(11) NOT NULL,
  `fixed_version_id` int(11) DEFAULT NULL,
  `author_id` int(11) NOT NULL,
  `lock_version` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `done_ratio` int(11) NOT NULL DEFAULT '0',
  `estimated_hours` float DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `root_id` int(11) DEFAULT NULL,
  `lft` int(11) DEFAULT NULL,
  `rgt` int(11) DEFAULT NULL,
  `is_private` tinyint(1) NOT NULL DEFAULT '0',
  `closed_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `issues_project_id` (`project_id`),
  KEY `index_issues_on_status_id` (`status_id`),
  KEY `index_issues_on_category_id` (`category_id`),
  KEY `index_issues_on_assigned_to_id` (`assigned_to_id`),
  KEY `index_issues_on_fixed_version_id` (`fixed_version_id`),
  KEY `index_issues_on_tracker_id` (`tracker_id`),
  KEY `index_issues_on_priority_id` (`priority_id`),
  KEY `index_issues_on_author_id` (`author_id`),
  KEY `index_issues_on_created_on` (`created_on`),
  KEY `index_issues_on_root_id_and_lft_and_rgt` (`root_id`,`lft`,`rgt`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issues`
--

LOCK TABLES `issues` WRITE;
/*!40000 ALTER TABLE `issues` DISABLE KEYS */;
INSERT INTO `issues` VALUES (1,1,1,'Realizar Diagnósticos e Tratativas','','2018-06-29',NULL,2,7,2,NULL,1,52,'2018-08-09 14:38:55','2018-08-20 14:09:13','2018-02-02',100,30,NULL,1,1,14,0,'2018-08-13 11:44:22'),(4,1,1,'Diagnóstico Banco de Dados','','2018-04-30',NULL,3,7,2,NULL,1,12,'2018-08-09 14:46:56','2018-08-20 14:04:48','2018-02-02',100,2,1,1,2,3,0,'2018-08-13 11:44:31'),(6,1,1,'Diagnóstico Infraestrutura','','2018-03-29',NULL,3,7,2,NULL,1,29,'2018-08-09 14:48:49','2018-08-20 14:05:22','2018-02-02',100,2,1,1,4,5,0,'2018-08-13 11:44:33'),(10,1,1,'Diagnóstico sistema','','2018-04-30',NULL,3,7,2,NULL,1,14,'2018-08-13 09:25:03','2018-08-20 14:05:52','2018-02-02',100,NULL,1,1,6,7,0,'2018-08-13 11:43:49'),(11,1,1,'Plano de ação ','','2018-06-29',NULL,1,7,2,NULL,1,10,'2018-08-13 09:29:38','2018-08-20 14:09:13','2018-03-01',100,NULL,1,1,8,9,0,'2018-08-13 11:44:37'),(12,1,1,'Tratativas  Imediatas','','2018-05-30',NULL,3,7,2,NULL,1,7,'2018-08-13 09:29:58','2018-08-20 14:10:00','2018-03-01',100,NULL,1,1,10,11,0,'2018-08-13 11:47:43'),(13,1,1,' Mapear Ações Futuras','','2018-06-29',NULL,3,7,2,NULL,1,10,'2018-08-13 09:30:18','2018-08-20 14:10:38','2018-04-18',100,NULL,1,1,12,13,0,'2018-08-13 11:47:41'),(17,1,1,'Implantar Gestão','','2018-06-29',NULL,1,1,2,NULL,1,10,'2018-08-14 13:02:05','2018-08-20 14:14:02','2018-03-02',100,NULL,NULL,17,1,12,0,NULL),(18,1,1,' Revisar Catálogo de Serviço','','2018-05-18',NULL,3,9,2,NULL,1,5,'2018-08-14 13:02:22','2018-08-20 14:11:31','2018-04-03',100,NULL,17,17,2,3,0,NULL),(19,1,1,'Definir Fluxo de Demanda','','2018-04-18',NULL,3,9,2,NULL,1,4,'2018-08-14 13:02:39','2018-08-20 14:12:48','2018-04-02',100,NULL,17,17,4,5,0,NULL),(20,1,1,'Revisar SLAs de Chamados ','','2018-06-15',NULL,3,9,2,NULL,1,4,'2018-08-14 13:02:56','2018-08-20 14:13:29','2018-03-02',100,NULL,17,17,6,7,0,NULL),(21,1,1,'Implantar indicadores de performance','','2018-06-29',NULL,3,9,2,NULL,1,4,'2018-08-14 13:03:20','2018-08-20 14:14:02','2018-03-02',100,NULL,17,17,8,9,0,NULL),(22,1,1,'Monitoramento de Processos de Negócio','','2018-06-29',NULL,3,7,2,NULL,1,4,'2018-08-14 13:04:08','2018-08-20 14:15:09','2018-04-18',100,NULL,17,17,10,11,0,NULL),(23,1,1,'Ferramenta de Gestão de Projetos','','2018-05-28',NULL,1,NULL,2,NULL,1,4,'2018-08-14 13:04:36','2018-08-20 14:18:38','2018-04-16',60,NULL,NULL,23,1,12,0,NULL),(24,1,1,' Mapear requisitos e fornecedores','','2018-05-28',NULL,3,8,2,NULL,1,4,'2018-08-14 13:04:53','2018-08-20 14:18:38','2018-04-16',100,NULL,23,23,2,3,0,NULL),(25,1,1,' Negociar plano de adesão','',NULL,NULL,3,7,2,NULL,1,3,'2018-08-14 13:05:07','2018-08-15 09:35:20','2018-08-14',100,NULL,23,23,4,5,0,NULL),(26,1,1,'Executar testes','',NULL,NULL,3,8,2,NULL,1,3,'2018-08-14 13:05:26','2018-08-15 09:35:32','2018-08-14',100,NULL,23,23,6,7,0,NULL),(27,1,1,'Implantar Projeto Piloto','',NULL,NULL,4,8,2,NULL,1,2,'2018-08-14 13:05:41','2018-08-15 09:25:35','2018-08-14',0,NULL,23,23,8,9,0,NULL),(28,1,1,'Mapear recomendações para demais projetos','',NULL,NULL,4,8,2,NULL,1,3,'2018-08-14 13:05:55','2018-08-15 09:25:42','2018-08-14',0,NULL,23,23,10,11,0,NULL),(29,1,1,'Implantar Governança','',NULL,NULL,1,NULL,2,NULL,1,11,'2018-08-14 13:07:16','2018-08-15 09:37:54','2018-08-14',61,NULL,NULL,29,1,38,0,NULL),(30,1,1,'Política de Governança','',NULL,NULL,5,8,2,NULL,1,2,'2018-08-14 13:07:30','2018-08-15 09:26:10','2018-08-14',0,NULL,29,29,2,3,0,'2018-08-15 09:26:10'),(31,1,1,' Política de Segurança da Informação','',NULL,NULL,3,9,2,NULL,1,4,'2018-08-14 13:07:44','2018-08-15 09:36:18','2018-08-14',100,NULL,29,29,4,5,0,NULL),(32,1,1,'POP Controle de Acessos','',NULL,NULL,5,9,2,NULL,1,2,'2018-08-14 13:08:03','2018-08-15 09:26:24','2018-08-14',0,NULL,29,29,6,7,0,'2018-08-15 09:26:24'),(33,1,1,' POP Rotina de Backup','',NULL,NULL,5,11,2,NULL,1,2,'2018-08-14 13:08:27','2018-08-15 09:26:32','2018-08-14',0,NULL,29,29,8,9,0,'2018-08-15 09:26:32'),(34,1,1,'Política de Acordo de Serviços','',NULL,NULL,3,9,2,NULL,1,3,'2018-08-14 13:08:46','2018-08-15 09:36:27','2018-08-14',100,NULL,29,29,10,11,0,NULL),(35,1,1,'POP Atendimento','',NULL,NULL,3,9,2,NULL,1,3,'2018-08-14 13:09:06','2018-08-15 09:36:39','2018-08-14',100,NULL,29,29,12,13,0,NULL),(36,1,1,'POP Abertura de Chamados','',NULL,NULL,3,9,2,NULL,1,3,'2018-08-14 13:09:20','2018-08-15 09:36:48','2018-08-14',100,NULL,29,29,14,15,0,NULL),(37,1,1,' Catálogo de Serviços ','',NULL,NULL,3,9,2,NULL,1,3,'2018-08-14 13:09:47','2018-08-15 09:36:56','2018-08-14',100,NULL,29,29,16,17,0,NULL),(38,1,1,'Política de Projetos','',NULL,NULL,4,9,2,NULL,1,2,'2018-08-14 13:10:06','2018-08-15 09:27:01','2018-08-14',0,NULL,29,29,18,19,0,NULL),(39,1,1,'POP Especificação de Requisitos','',NULL,NULL,4,9,2,NULL,1,2,'2018-08-14 13:10:20','2018-08-15 09:27:09','2018-08-14',0,NULL,29,29,20,21,0,NULL),(40,1,1,'POP Desenvolvimento','',NULL,NULL,4,9,2,NULL,1,2,'2018-08-14 13:10:33','2018-08-15 09:27:17','2018-08-14',0,NULL,29,29,22,23,0,NULL),(41,1,1,' POP Testes e  Homologação','',NULL,NULL,4,9,2,NULL,1,2,'2018-08-14 13:10:49','2018-08-15 09:27:23','2018-08-14',0,NULL,29,29,24,25,0,NULL),(42,1,1,' POP Implantação ','',NULL,NULL,4,9,2,NULL,1,2,'2018-08-14 13:11:18','2018-08-15 09:27:32','2018-08-14',0,NULL,29,29,26,27,0,NULL),(43,1,1,' Política de Fornecedores','',NULL,NULL,4,8,2,NULL,1,2,'2018-08-14 13:11:33','2018-08-15 09:27:38','2018-08-14',0,NULL,29,29,28,29,0,NULL),(44,1,1,'POP Gestão de Contratos','',NULL,NULL,3,10,2,NULL,1,3,'2018-08-14 13:11:49','2018-08-15 09:37:24','2018-08-14',100,NULL,29,29,30,31,0,NULL),(45,1,1,'Política de Desenvolvimento Rápido','',NULL,NULL,4,9,2,NULL,1,2,'2018-08-14 13:12:02','2018-08-15 09:27:55','2018-08-14',0,NULL,29,29,32,33,0,NULL),(46,1,1,' Política de Alocação de Equipamentos','',NULL,NULL,3,8,2,NULL,1,3,'2018-08-14 13:12:15','2018-08-15 09:37:37','2018-08-14',100,NULL,29,29,34,35,0,NULL),(47,1,1,'Treinamento e Implementação das Políticas','',NULL,NULL,3,8,2,NULL,1,3,'2018-08-14 13:12:31','2018-08-15 09:37:54','2018-08-14',100,NULL,29,29,36,37,0,NULL),(48,1,1,' Avaliação da Estrutura da Equipe de TI','',NULL,NULL,1,NULL,2,NULL,1,0,'2018-08-14 13:12:49','2018-08-14 13:12:49','2018-08-14',0,NULL,NULL,48,1,6,0,NULL),(49,1,1,' Adequação de funções e responsabilidades','',NULL,NULL,3,7,2,NULL,1,2,'2018-08-14 13:13:30','2018-08-15 09:28:45','2018-08-14',0,NULL,48,48,2,3,0,NULL),(50,1,1,'Monitorar capacidade e cumprimento de SLA','',NULL,NULL,3,7,2,NULL,1,2,'2018-08-14 13:13:49','2018-08-15 09:28:53','2018-08-14',0,NULL,48,48,4,5,0,NULL),(78,1,2,'Levantamento de requisitos','','2018-08-02',NULL,3,NULL,2,NULL,1,6,'2018-08-17 08:26:09','2018-08-17 08:42:58','2018-07-30',100,NULL,NULL,78,1,6,0,NULL),(79,1,2,'Levantamento de requisitos de infraestrutura ','','2018-07-31',NULL,3,5,2,NULL,1,1,'2018-08-17 08:26:42','2018-08-17 08:27:30','2018-07-30',100,NULL,78,78,2,3,0,NULL),(80,1,2,'Levantamento de requisitos funcionais','','2018-08-02',NULL,3,13,2,NULL,1,2,'2018-08-17 08:27:16','2018-08-17 08:42:58','2018-08-01',100,NULL,78,78,4,5,0,NULL),(81,1,2,'Desenvolvimento da aplicação ','','2018-08-30',NULL,2,NULL,2,NULL,1,7,'2018-08-17 08:28:28','2018-08-17 08:45:12','2018-08-03',0,NULL,NULL,81,1,8,0,NULL),(82,1,2,'Customização do Redmine','','2018-08-23',NULL,2,5,2,NULL,1,3,'2018-08-17 08:29:09','2018-08-17 08:44:36','2018-08-03',0,NULL,81,81,2,3,0,NULL),(83,1,2,'Testes pós customização ','','2018-08-27',NULL,1,6,2,NULL,1,3,'2018-08-17 08:30:05','2018-08-17 08:44:53','2018-08-24',0,NULL,81,81,4,5,0,NULL),(84,1,2,'Validação com usuários ','','2018-08-30',NULL,1,5,2,NULL,1,1,'2018-08-17 08:34:15','2018-08-17 08:45:12','2018-08-28',0,NULL,81,81,6,7,0,NULL),(85,1,2,'GO LIVE','','2018-08-31',NULL,1,5,2,NULL,1,4,'2018-08-17 08:36:00','2018-08-20 10:16:48','2018-08-31',0,NULL,NULL,85,1,2,0,NULL),(111,1,5,'Realizar Diagnósticos e Tratativas','','2018-06-29',NULL,3,NULL,2,NULL,1,3,'2018-08-21 09:23:02','2018-08-21 10:09:04','2018-02-02',0,NULL,NULL,111,1,14,0,NULL),(112,1,5,'Diagnóstico Banco de Dados','','2018-04-30',NULL,3,7,2,NULL,1,4,'2018-08-21 09:23:53','2018-08-21 10:09:03','2018-02-02',0,NULL,111,111,2,3,0,NULL),(113,1,5,'Diagnóstico Infraestrutura','','2018-03-29',NULL,3,7,2,NULL,1,1,'2018-08-21 09:24:34','2018-08-21 10:09:07','2018-02-02',0,NULL,111,111,4,5,0,NULL),(114,1,5,'Diagnóstico Sistema ','','2018-04-30',NULL,3,7,2,NULL,1,3,'2018-08-21 09:25:22','2018-08-21 10:12:36','2018-02-02',0,NULL,111,111,6,7,0,NULL),(115,1,5,'Plano de Ação','','2018-06-29',NULL,1,7,2,NULL,1,0,'2018-08-21 09:29:31','2018-08-21 09:29:31','2018-03-01',0,NULL,111,111,8,9,0,NULL),(116,1,5,'Tratativas  Imediatas','','2018-05-30',NULL,3,7,2,NULL,1,1,'2018-08-21 09:33:23','2018-08-21 10:09:41','2018-03-01',0,NULL,111,111,10,11,0,NULL),(117,1,5,' Mapear Ações Futuras','','2018-06-29',NULL,3,7,2,NULL,1,1,'2018-08-21 09:34:04','2018-08-21 10:09:45','2018-04-18',0,NULL,111,111,12,13,0,NULL),(118,1,5,'Implantar gestão','','2018-06-29',NULL,1,NULL,2,NULL,1,4,'2018-08-21 10:00:34','2018-08-21 10:03:40','2018-03-02',0,NULL,NULL,118,1,12,0,NULL),(119,1,5,' Revisar Catálogo de Serviço','','2018-05-18',NULL,3,9,2,NULL,1,1,'2018-08-21 10:01:16','2018-08-21 10:10:28','2018-04-03',0,NULL,118,118,2,3,0,NULL),(120,1,5,'Definir Fluxo de Demanda','','2018-04-18',NULL,3,9,2,NULL,1,1,'2018-08-21 10:01:53','2018-08-21 10:10:32','2018-04-02',0,NULL,118,118,4,5,0,NULL),(121,1,5,'Revisar SLAs de Chamados ','','2018-06-15',NULL,3,9,2,NULL,1,1,'2018-08-21 10:03:04','2018-08-21 10:10:34','2018-03-02',0,NULL,118,118,6,7,0,NULL),(122,1,5,'Implantar indicadores de performance','','2018-06-29',NULL,3,9,2,NULL,1,1,'2018-08-21 10:03:39','2018-08-21 10:10:39','2018-03-02',0,NULL,118,118,8,9,0,NULL),(123,1,5,'Monitoramento de Processos de Negócio','','2018-06-29',NULL,3,7,2,NULL,1,1,'2018-08-21 10:04:17','2018-08-21 10:10:49','2018-04-18',0,NULL,118,118,10,11,0,NULL),(124,1,5,'Ferramenta de Gestão de Projetos','','2018-08-10',NULL,1,NULL,2,NULL,1,5,'2018-08-21 10:05:12','2018-08-21 10:08:40','2018-04-16',0,NULL,NULL,124,1,12,0,NULL),(125,1,5,' Mapear requisitos e fornecedores','','2018-05-28',NULL,3,8,2,NULL,1,1,'2018-08-21 10:05:59','2018-08-21 10:11:11','2018-04-16',0,NULL,124,124,2,3,0,NULL),(126,1,5,' Negociar plano de adesão','','2018-06-28',NULL,3,7,2,NULL,1,1,'2018-08-21 10:06:44','2018-08-21 10:12:10','2018-05-02',0,NULL,124,124,4,5,0,NULL),(127,1,5,'Executar testes','','2018-06-29',NULL,3,8,2,NULL,1,1,'2018-08-21 10:07:25','2018-08-21 10:12:21','2018-05-10',0,NULL,124,124,6,7,0,NULL),(128,1,5,'Implantar Projeto Piloto','','2018-07-31',NULL,4,8,2,NULL,1,1,'2018-08-21 10:08:14','2018-08-21 10:11:27','2018-07-02',0,NULL,124,124,8,9,0,NULL),(129,1,5,'Mapear recomendações para demais projetos','','2018-08-10',NULL,4,8,2,NULL,1,1,'2018-08-21 10:08:40','2018-08-21 10:11:30','2018-08-01',0,NULL,124,124,10,11,0,NULL);
/*!40000 ALTER TABLE `issues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal_details`
--

DROP TABLE IF EXISTS `journal_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `journal_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `journal_id` int(11) NOT NULL DEFAULT '0',
  `property` varchar(30) NOT NULL DEFAULT '',
  `prop_key` varchar(30) NOT NULL DEFAULT '',
  `old_value` text,
  `value` text,
  PRIMARY KEY (`id`),
  KEY `journal_details_journal_id` (`journal_id`)
) ENGINE=InnoDB AUTO_INCREMENT=501 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal_details`
--

LOCK TABLES `journal_details` WRITE;
/*!40000 ALTER TABLE `journal_details` DISABLE KEYS */;
INSERT INTO `journal_details` VALUES (1,1,'attr','status_id','1','2'),(2,2,'attr','status_id','2','5'),(7,7,'attr','estimated_hours','10.0','30.0'),(8,8,'attr','estimated_hours',NULL,'2.0'),(9,9,'attr','assigned_to_id',NULL,'5'),(10,10,'attr','assigned_to_id',NULL,'5'),(11,11,'attr','assigned_to_id',NULL,'5'),(12,12,'attr','status_id','1','2'),(13,13,'attr','status_id','1','3'),(14,14,'attr','status_id','2','3'),(15,15,'attr','status_id','5','2'),(16,16,'attr','status_id','2','4'),(17,17,'relation','relates',NULL,'4'),(18,18,'relation','relates',NULL,'6'),(19,19,'relation','relates','4',NULL),(20,20,'relation','relates','6',NULL),(21,21,'attr','due_date','2018-08-25','2018-09-19'),(22,21,'attr','start_date','2018-08-09','2018-09-03'),(23,22,'relation','precedes',NULL,'6'),(24,21,'relation','follows',NULL,'4'),(25,23,'relation','precedes','6',NULL),(26,24,'relation','follows','4',NULL),(27,25,'relation','blocks',NULL,'6'),(28,26,'relation','blocked',NULL,'4'),(29,27,'attr','done_ratio','0','20'),(30,28,'relation','blocks','6',NULL),(31,29,'relation','blocked','4',NULL),(32,30,'relation','precedes',NULL,'6'),(33,31,'relation','follows',NULL,'4'),(34,32,'relation','precedes','6',NULL),(35,33,'relation','follows','4',NULL),(36,34,'relation','blocks',NULL,'6'),(37,35,'relation','blocked',NULL,'4'),(38,37,'attr','done_ratio','20','40'),(39,38,'relation','blocks','6',NULL),(40,39,'relation','blocked','4',NULL),(41,40,'relation','blocks',NULL,'6'),(42,41,'relation','blocked',NULL,'4'),(43,42,'attr','done_ratio','40','70'),(44,43,'relation','blocks','6',NULL),(45,44,'relation','blocked','4',NULL),(46,45,'relation','blocks',NULL,'6'),(47,46,'relation','blocked',NULL,'4'),(48,47,'relation','blocks','6',NULL),(49,48,'relation','blocked','4',NULL),(50,49,'relation','blocks',NULL,'6'),(51,50,'relation','blocked',NULL,'4'),(54,54,'attr','status_id','3','2'),(55,55,'attr','done_ratio','70','100'),(56,56,'relation','blocks','6',NULL),(57,57,'relation','blocked','4',NULL),(58,58,'relation','blocks',NULL,'6'),(59,59,'relation','blocked',NULL,'4'),(60,60,'attr','done_ratio','100','30'),(61,61,'attr','status_id','2','3'),(62,62,'attr','status_id','3','2'),(63,63,'attr','status_id','2','1'),(64,64,'attr','status_id','1','2'),(65,65,'attr','status_id','2','3'),(66,66,'attr','status_id','3','2'),(67,67,'attr','status_id','2','3'),(83,83,'attr','assigned_to_id',NULL,'5'),(84,84,'attr','status_id','1','2'),(85,85,'attr','status_id','1','2'),(86,86,'attr','status_id','2','3'),(87,87,'attr','status_id','3','4'),(88,88,'attr','status_id','3','4'),(89,89,'attr','status_id','4','3'),(90,90,'attr','status_id','4','6'),(91,91,'attr','status_id','4','6'),(92,92,'attr','status_id','3','6'),(93,93,'attr','status_id','3','6'),(94,94,'attr','status_id','2','6'),(95,95,'attr','status_id','1','6'),(96,96,'attr','status_id','1','6'),(97,97,'attr','assigned_to_id',NULL,'5'),(98,98,'attr','assigned_to_id',NULL,'5'),(99,99,'attr','assigned_to_id',NULL,'5'),(100,100,'attr','status_id','6','1'),(101,101,'attr','status_id','6','2'),(102,102,'attr','status_id','6','3'),(103,103,'attr','status_id','6','4'),(104,104,'attr','status_id','6','5'),(105,105,'attr','status_id','6','5'),(106,106,'attr','status_id','4','5'),(107,107,'attr','status_id','3','5'),(108,108,'attr','status_id','6','4'),(109,109,'attr','status_id','5','3'),(110,110,'attr','status_id','5','6'),(111,111,'attr','status_id','5','6'),(112,112,'attr','status_id','5','6'),(113,113,'attr','status_id','6','3'),(114,114,'attr','status_id','6','2'),(125,123,'attr','subject','Implantar Projeto Piloto','Mapear recomendações para demais projetos'),(126,124,'attr','assigned_to_id','5','7'),(127,125,'attr','assigned_to_id','5','7'),(128,126,'attr','assigned_to_id','5','7'),(129,127,'attr','assigned_to_id','5','7'),(130,128,'attr','assigned_to_id','5','7'),(131,129,'attr','assigned_to_id','5','7'),(132,130,'attr','assigned_to_id','5',NULL),(133,131,'attr','assigned_to_id','5','1'),(134,132,'attr','assigned_to_id',NULL,'9'),(135,133,'attr','assigned_to_id',NULL,'9'),(136,134,'attr','assigned_to_id',NULL,'9'),(137,135,'attr','assigned_to_id',NULL,'9'),(138,136,'attr','assigned_to_id',NULL,'7'),(139,137,'attr','assigned_to_id',NULL,'8'),(140,138,'attr','assigned_to_id',NULL,'7'),(141,139,'attr','assigned_to_id',NULL,'8'),(142,140,'attr','assigned_to_id',NULL,'8'),(143,141,'attr','assigned_to_id',NULL,'8'),(144,142,'attr','assigned_to_id',NULL,'8'),(145,143,'attr','assigned_to_id',NULL,'8'),(146,144,'attr','assigned_to_id','8','9'),(147,145,'attr','assigned_to_id',NULL,'9'),(148,146,'attr','assigned_to_id',NULL,'11'),(149,147,'attr','assigned_to_id',NULL,'9'),(150,148,'attr','assigned_to_id',NULL,'9'),(151,149,'attr','assigned_to_id',NULL,'9'),(152,150,'attr','assigned_to_id',NULL,'9'),(153,151,'attr','assigned_to_id',NULL,'9'),(154,152,'attr','assigned_to_id',NULL,'9'),(155,153,'attr','assigned_to_id',NULL,'9'),(156,154,'attr','assigned_to_id',NULL,'9'),(157,155,'attr','assigned_to_id',NULL,'9'),(158,156,'attr','assigned_to_id',NULL,'8'),(159,157,'attr','assigned_to_id',NULL,'10'),(160,158,'attr','assigned_to_id',NULL,'9'),(161,159,'attr','assigned_to_id',NULL,'8'),(162,160,'attr','assigned_to_id',NULL,'8'),(163,161,'attr','assigned_to_id',NULL,'7'),(164,162,'attr','assigned_to_id',NULL,'7'),(165,163,'relation','blocks','6',NULL),(166,164,'relation','blocked','4',NULL),(167,165,'attr','due_date','2018-08-20','2018-09-27'),(168,165,'attr','start_date','2018-08-13','2018-09-20'),(169,166,'relation','precedes',NULL,'10'),(170,165,'relation','follows',NULL,'6'),(171,167,'relation','precedes','10',NULL),(172,168,'relation','follows','6',NULL),(173,169,'attr','due_date',NULL,'2018-10-01'),(174,169,'attr','start_date','2018-08-13','2018-10-01'),(175,170,'relation','precedes',NULL,'11'),(176,169,'relation','follows',NULL,'10'),(245,219,'attr','status_id','1','3'),(246,220,'attr','status_id','4','3'),(247,221,'attr','status_id','2','1'),(248,222,'attr','status_id','1','3'),(249,223,'attr','status_id','1','3'),(250,224,'attr','status_id','1','3'),(251,225,'attr','status_id','1','3'),(252,226,'attr','status_id','1','3'),(253,227,'attr','status_id','1','3'),(254,228,'attr','status_id','1','3'),(255,229,'attr','status_id','1','3'),(256,230,'attr','status_id','1','4'),(257,231,'attr','status_id','1','4'),(258,232,'attr','status_id','1','5'),(259,233,'attr','status_id','1','3'),(260,234,'attr','status_id','1','5'),(261,235,'attr','status_id','1','5'),(262,236,'attr','status_id','1','3'),(263,237,'attr','status_id','1','3'),(264,238,'attr','status_id','1','3'),(265,239,'attr','status_id','1','3'),(266,240,'attr','status_id','1','4'),(267,241,'attr','status_id','1','4'),(268,242,'attr','status_id','1','4'),(269,243,'attr','status_id','1','4'),(270,244,'attr','status_id','1','4'),(271,245,'attr','status_id','1','4'),(272,246,'attr','status_id','1','3'),(273,247,'attr','status_id','1','4'),(274,248,'attr','status_id','1','3'),(275,249,'attr','status_id','1','3'),(276,250,'attr','status_id','1','3'),(277,251,'attr','status_id','1','3'),(278,252,'attr','done_ratio','0','100'),(279,253,'attr','done_ratio','30','100'),(280,254,'attr','done_ratio','0','100'),(281,255,'attr','done_ratio','0','100'),(282,256,'attr','done_ratio','0','100'),(283,257,'attr','done_ratio','0','100'),(284,258,'attr','done_ratio','0','100'),(285,259,'attr','done_ratio','0','100'),(286,260,'attr','done_ratio','0','100'),(287,261,'attr','done_ratio','0','100'),(288,262,'attr','done_ratio','0','100'),(289,263,'attr','done_ratio','0','100'),(290,264,'attr','done_ratio','0','100'),(291,265,'attr','done_ratio','0','100'),(292,266,'attr','done_ratio','0','100'),(293,267,'attr','done_ratio','0','100'),(294,268,'attr','done_ratio','0','100'),(295,269,'attr','done_ratio','0','100'),(296,270,'attr','done_ratio','0','100'),(297,271,'attr','done_ratio','0','100'),(298,272,'attr','done_ratio','0','100'),(308,279,'attr','status_id','6','3'),(309,279,'attr','assigned_to_id','5','7'),(310,279,'attr','done_ratio','0','100'),(328,295,'attr','status_id','1','3'),(329,295,'attr','done_ratio','0','100'),(330,296,'attr','status_id','1','3'),(331,296,'attr','done_ratio','0','100'),(332,297,'attr','status_id','1','3'),(333,298,'attr','subject','TESTES PÓS CUSTOMIZAÇÃO','Testes pós customização '),(334,299,'attr','due_date','2018-08-31','2018-08-28'),(335,300,'attr','status_id','1','2'),(336,301,'attr','status_id','1','2'),(337,302,'attr','assigned_to_id',NULL,'5'),(338,303,'attr','due_date','2018-08-03','2018-08-02'),(339,303,'attr','start_date','2018-08-02','2018-08-01'),(340,304,'relation','precedes',NULL,'80'),(341,303,'relation','follows',NULL,'79'),(342,305,'attr','due_date','2018-08-24','2018-08-23'),(343,305,'attr','start_date','2018-08-06','2018-08-03'),(344,306,'relation','precedes',NULL,'82'),(345,305,'relation','follows',NULL,'80'),(346,307,'attr','due_date','2018-08-28','2018-08-27'),(347,307,'attr','start_date','2018-08-27','2018-08-24'),(348,308,'relation','precedes',NULL,'83'),(349,307,'relation','follows',NULL,'82'),(350,309,'attr','due_date','2018-08-31','2018-08-30'),(351,309,'attr','start_date','2018-08-29','2018-08-28'),(352,310,'relation','precedes',NULL,'84'),(353,309,'relation','follows',NULL,'83'),(354,311,'attr','due_date',NULL,'2018-08-31'),(355,311,'attr','start_date','2018-09-03','2018-08-31'),(356,312,'relation','precedes',NULL,'85'),(357,311,'relation','follows',NULL,'84'),(358,313,'attr','status_id','1','2'),(359,314,'attr','status_id','2','1'),(382,333,'attr','due_date','2018-09-08','2018-04-30'),(383,333,'attr','start_date','2018-08-19','2018-02-02'),(384,334,'attr','due_date','2018-09-19','2018-03-29'),(385,334,'attr','start_date','2018-09-03','2018-02-02'),(386,335,'attr','due_date','2018-09-27','2018-04-30'),(387,335,'attr','start_date','2018-09-20','2018-02-02'),(388,336,'relation','precedes','11',NULL),(389,337,'relation','follows','10',NULL),(390,338,'attr','due_date','2018-05-03','2018-06-29'),(391,338,'attr','start_date','2018-05-03','2018-03-01'),(392,339,'attr','due_date',NULL,'2018-05-30'),(393,339,'attr','start_date','2018-08-13','2018-03-01'),(394,340,'attr','due_date',NULL,'2018-06-29'),(395,340,'attr','start_date','2018-08-14','2018-04-18'),(396,341,'attr','due_date',NULL,'2018-05-18'),(397,341,'attr','start_date','2018-08-14','2018-04-03'),(398,342,'attr','due_date',NULL,'2018-04-18'),(399,342,'attr','start_date','2018-08-14','2018-04-02'),(400,343,'attr','due_date',NULL,'2018-06-15'),(401,343,'attr','start_date','2018-08-14','2018-03-02'),(402,344,'attr','due_date',NULL,'2018-06-29'),(403,344,'attr','start_date','2018-08-14','2018-03-02'),(404,345,'attr','due_date',NULL,'2018-06-29'),(405,345,'attr','start_date','2018-08-14','2018-04-18'),(406,346,'attr','due_date',NULL,'2018-05-28'),(407,346,'attr','start_date','2018-08-14','2018-04-16'),(480,396,'attr','status_id','1','2'),(481,397,'attr','status_id','2','1'),(482,398,'attr','status_id','1','2'),(483,399,'attr','status_id','2','3'),(484,400,'attr','status_id','1','3'),(485,401,'attr','status_id','1','3'),(486,402,'attr','status_id','1','2'),(487,403,'attr','status_id','2','3'),(488,404,'attr','status_id','1','3'),(489,405,'attr','status_id','1','3'),(490,406,'attr','status_id','1','3'),(491,407,'attr','status_id','1','3'),(492,408,'attr','status_id','1','3'),(493,409,'attr','status_id','1','3'),(494,410,'attr','status_id','1','3'),(495,411,'attr','status_id','1','3'),(496,412,'attr','status_id','1','4'),(497,413,'attr','status_id','1','4'),(498,414,'attr','status_id','1','3'),(499,415,'attr','status_id','1','3'),(500,416,'attr','assigned_to_id','8','7');
/*!40000 ALTER TABLE `journal_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journals`
--

DROP TABLE IF EXISTS `journals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `journals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `journalized_id` int(11) NOT NULL DEFAULT '0',
  `journalized_type` varchar(30) NOT NULL DEFAULT '',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `notes` text,
  `created_on` datetime NOT NULL,
  `private_notes` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `journals_journalized_id` (`journalized_id`,`journalized_type`),
  KEY `index_journals_on_user_id` (`user_id`),
  KEY `index_journals_on_journalized_id` (`journalized_id`),
  KEY `index_journals_on_created_on` (`created_on`)
) ENGINE=InnoDB AUTO_INCREMENT=417 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journals`
--

LOCK TABLES `journals` WRITE;
/*!40000 ALTER TABLE `journals` DISABLE KEYS */;
INSERT INTO `journals` VALUES (1,1,'Issue',1,'Transição de status aplicada automaticamente devido ao início do time tracker.','2018-08-09 14:39:34',0),(2,1,'Issue',1,'','2018-08-09 14:39:59',0),(7,1,'Issue',1,'','2018-08-09 14:47:10',0),(8,4,'Issue',1,'','2018-08-09 14:47:34',0),(9,1,'Issue',1,'','2018-08-09 14:50:40',0),(10,4,'Issue',1,'','2018-08-09 14:50:51',0),(11,6,'Issue',1,'','2018-08-09 14:51:01',0),(12,6,'Issue',1,'','2018-08-09 15:01:18',0),(13,4,'Issue',1,'','2018-08-09 15:01:41',0),(14,6,'Issue',1,'','2018-08-09 15:01:54',0),(15,1,'Issue',1,'','2018-08-09 15:09:04',0),(16,1,'Issue',1,'','2018-08-10 10:15:54',0),(17,6,'Issue',1,'','2018-08-10 10:47:01',0),(18,4,'Issue',1,'','2018-08-10 10:47:01',0),(19,6,'Issue',1,'','2018-08-10 10:59:11',0),(20,4,'Issue',1,'','2018-08-10 10:59:12',0),(21,6,'Issue',1,'','2018-08-10 10:59:36',0),(22,4,'Issue',1,'','2018-08-10 10:59:36',0),(23,4,'Issue',1,'','2018-08-10 10:59:51',0),(24,6,'Issue',1,'','2018-08-10 10:59:51',0),(25,4,'Issue',1,'','2018-08-10 11:00:07',0),(26,6,'Issue',1,'','2018-08-10 11:00:07',0),(27,6,'Issue',1,'','2018-08-10 11:00:49',0),(28,4,'Issue',1,'','2018-08-10 11:01:03',0),(29,6,'Issue',1,'','2018-08-10 11:01:03',0),(30,4,'Issue',1,'','2018-08-10 11:01:26',0),(31,6,'Issue',1,'','2018-08-10 11:01:26',0),(32,4,'Issue',1,'','2018-08-10 11:01:53',0),(33,6,'Issue',1,'','2018-08-10 11:01:53',0),(34,4,'Issue',1,'','2018-08-10 11:02:15',0),(35,6,'Issue',1,'','2018-08-10 11:02:15',0),(36,6,'Issue',5,'efefe','2018-08-10 11:03:53',0),(37,6,'Issue',5,'','2018-08-10 11:04:18',0),(38,4,'Issue',5,'','2018-08-10 11:04:26',0),(39,6,'Issue',5,'','2018-08-10 11:04:26',0),(40,4,'Issue',1,'','2018-08-10 11:04:56',0),(41,6,'Issue',1,'','2018-08-10 11:04:57',0),(42,6,'Issue',1,'','2018-08-10 11:05:37',0),(43,4,'Issue',1,'','2018-08-10 11:12:27',0),(44,6,'Issue',1,'','2018-08-10 11:12:27',0),(45,4,'Issue',1,'','2018-08-10 11:12:57',0),(46,6,'Issue',1,'','2018-08-10 11:12:57',0),(47,4,'Issue',1,'','2018-08-10 11:13:07',0),(48,6,'Issue',1,'','2018-08-10 11:13:07',0),(49,4,'Issue',1,'','2018-08-10 11:13:17',0),(50,6,'Issue',1,'','2018-08-10 11:13:17',0),(53,6,'Issue',1,'rtrhthrththtrhrth','2018-08-10 11:28:23',0),(54,6,'Issue',1,'','2018-08-10 11:28:50',0),(55,6,'Issue',1,'','2018-08-10 11:29:10',0),(56,4,'Issue',1,'','2018-08-10 11:33:01',0),(57,6,'Issue',1,'','2018-08-10 11:33:01',0),(58,4,'Issue',1,'','2018-08-10 11:53:19',0),(59,6,'Issue',1,'','2018-08-10 11:53:19',0),(60,6,'Issue',1,'','2018-08-10 12:12:29',0),(61,6,'Issue',1,'','2018-08-13 08:43:44',0),(62,6,'Issue',1,'','2018-08-13 08:44:01',0),(63,6,'Issue',1,'','2018-08-13 08:44:26',0),(64,6,'Issue',1,'','2018-08-13 08:44:47',0),(65,6,'Issue',1,'','2018-08-13 08:45:19',0),(66,6,'Issue',1,'','2018-08-13 08:45:27',0),(67,6,'Issue',1,'','2018-08-13 08:45:32',0),(83,10,'Issue',1,'','2018-08-13 11:19:09',0),(84,10,'Issue',1,'','2018-08-13 11:20:46',0),(85,11,'Issue',1,'','2018-08-13 11:29:20',0),(86,10,'Issue',1,'','2018-08-13 11:34:42',0),(87,10,'Issue',1,'','2018-08-13 11:36:42',0),(88,6,'Issue',1,'','2018-08-13 11:41:31',0),(89,6,'Issue',1,'','2018-08-13 11:42:41',0),(90,10,'Issue',1,'','2018-08-13 11:43:49',0),(91,1,'Issue',1,'','2018-08-13 11:44:22',0),(92,4,'Issue',1,'','2018-08-13 11:44:31',0),(93,6,'Issue',1,'','2018-08-13 11:44:33',0),(94,11,'Issue',1,'','2018-08-13 11:44:37',0),(95,13,'Issue',1,'','2018-08-13 11:44:39',0),(96,12,'Issue',1,'','2018-08-13 11:44:40',0),(97,11,'Issue',1,'','2018-08-13 11:46:01',0),(98,12,'Issue',1,'','2018-08-13 11:46:09',0),(99,13,'Issue',1,'','2018-08-13 11:46:16',0),(100,4,'Issue',1,'','2018-08-13 11:46:37',0),(101,11,'Issue',1,'','2018-08-13 11:46:47',0),(102,12,'Issue',1,'','2018-08-13 11:46:49',0),(103,13,'Issue',1,'','2018-08-13 11:46:51',0),(104,1,'Issue',1,'','2018-08-13 11:47:02',0),(105,10,'Issue',1,'','2018-08-13 11:47:10',0),(106,13,'Issue',1,'','2018-08-13 11:47:41',0),(107,12,'Issue',1,'','2018-08-13 11:47:43',0),(108,6,'Issue',1,'','2018-08-13 11:47:45',0),(109,13,'Issue',1,'','2018-08-13 11:47:47',0),(110,12,'Issue',1,'','2018-08-13 11:47:49',0),(111,1,'Issue',1,'','2018-08-13 11:47:50',0),(112,10,'Issue',1,'','2018-08-13 11:47:51',0),(113,10,'Issue',1,'','2018-08-13 11:47:53',0),(114,1,'Issue',1,'','2018-08-13 11:47:55',0),(123,28,'Issue',1,'','2018-08-14 13:06:16',0),(124,1,'Issue',1,'','2018-08-14 13:18:27',0),(125,4,'Issue',1,'','2018-08-14 13:19:00',0),(126,6,'Issue',1,'','2018-08-14 13:19:09',0),(127,10,'Issue',1,'','2018-08-14 13:19:18',0),(128,11,'Issue',1,'','2018-08-14 13:19:31',0),(129,13,'Issue',1,'','2018-08-14 13:20:05',0),(130,18,'Issue',1,'','2018-08-14 13:20:18',0),(131,17,'Issue',1,'','2018-08-14 13:20:30',0),(132,18,'Issue',1,'','2018-08-14 13:20:54',0),(133,19,'Issue',1,'','2018-08-14 13:21:06',0),(134,20,'Issue',1,'','2018-08-14 13:21:33',0),(135,21,'Issue',1,'','2018-08-14 13:21:51',0),(136,22,'Issue',1,'','2018-08-14 13:22:04',0),(137,24,'Issue',1,'','2018-08-14 13:22:21',0),(138,25,'Issue',1,'','2018-08-14 13:22:33',0),(139,26,'Issue',1,'','2018-08-14 13:22:44',0),(140,27,'Issue',1,'','2018-08-14 13:22:57',0),(141,28,'Issue',1,'','2018-08-14 13:23:13',0),(142,30,'Issue',1,'','2018-08-14 13:23:45',0),(143,31,'Issue',1,'','2018-08-14 13:23:53',0),(144,31,'Issue',1,'','2018-08-14 13:24:16',0),(145,32,'Issue',1,'','2018-08-14 13:24:27',0),(146,33,'Issue',1,'','2018-08-14 13:24:42',0),(147,34,'Issue',1,'','2018-08-14 13:24:56',0),(148,35,'Issue',1,'','2018-08-14 13:25:05',0),(149,36,'Issue',1,'','2018-08-14 13:25:20',0),(150,37,'Issue',1,'','2018-08-14 13:25:51',0),(151,38,'Issue',1,'','2018-08-14 13:26:10',0),(152,39,'Issue',1,'','2018-08-14 13:26:26',0),(153,40,'Issue',1,'','2018-08-14 13:26:38',0),(154,41,'Issue',1,'','2018-08-14 13:27:02',0),(155,42,'Issue',1,'','2018-08-14 13:27:15',0),(156,43,'Issue',1,'','2018-08-14 13:27:29',0),(157,44,'Issue',1,'','2018-08-14 13:27:45',0),(158,45,'Issue',1,'','2018-08-14 13:28:03',0),(159,46,'Issue',1,'','2018-08-14 13:28:19',0),(160,47,'Issue',1,'','2018-08-14 13:28:28',0),(161,49,'Issue',1,'','2018-08-14 13:28:43',0),(162,50,'Issue',1,'','2018-08-14 13:28:52',0),(163,4,'Issue',1,'','2018-08-14 14:25:50',0),(164,6,'Issue',1,'','2018-08-14 14:25:50',0),(165,10,'Issue',1,'','2018-08-14 14:27:15',0),(166,6,'Issue',1,'','2018-08-14 14:27:15',0),(167,6,'Issue',1,'','2018-08-14 14:27:29',0),(168,10,'Issue',1,'','2018-08-14 14:27:29',0),(169,11,'Issue',1,'','2018-08-14 14:27:44',0),(170,10,'Issue',1,'','2018-08-14 14:27:44',0),(219,4,'Issue',1,'','2018-08-15 09:21:49',0),(220,6,'Issue',1,'','2018-08-15 09:21:57',0),(221,11,'Issue',1,'','2018-08-15 09:22:14',0),(222,18,'Issue',1,'','2018-08-15 09:24:21',0),(223,19,'Issue',1,'','2018-08-15 09:24:29',0),(224,20,'Issue',1,'','2018-08-15 09:24:37',0),(225,21,'Issue',1,'','2018-08-15 09:24:42',0),(226,22,'Issue',1,'','2018-08-15 09:24:52',0),(227,24,'Issue',1,'','2018-08-15 09:25:09',0),(228,25,'Issue',1,'','2018-08-15 09:25:20',0),(229,26,'Issue',1,'','2018-08-15 09:25:28',0),(230,27,'Issue',1,'','2018-08-15 09:25:35',0),(231,28,'Issue',1,'','2018-08-15 09:25:42',0),(232,30,'Issue',1,'','2018-08-15 09:26:10',0),(233,31,'Issue',1,'','2018-08-15 09:26:16',0),(234,32,'Issue',1,'','2018-08-15 09:26:24',0),(235,33,'Issue',1,'','2018-08-15 09:26:32',0),(236,34,'Issue',1,'','2018-08-15 09:26:38',0),(237,35,'Issue',1,'','2018-08-15 09:26:44',0),(238,36,'Issue',1,'','2018-08-15 09:26:49',0),(239,37,'Issue',1,'','2018-08-15 09:26:56',0),(240,38,'Issue',1,'','2018-08-15 09:27:01',0),(241,39,'Issue',1,'','2018-08-15 09:27:09',0),(242,40,'Issue',1,'','2018-08-15 09:27:17',0),(243,41,'Issue',1,'','2018-08-15 09:27:23',0),(244,42,'Issue',1,'','2018-08-15 09:27:33',0),(245,43,'Issue',1,'','2018-08-15 09:27:38',0),(246,44,'Issue',1,'','2018-08-15 09:27:46',0),(247,45,'Issue',1,'','2018-08-15 09:27:55',0),(248,46,'Issue',1,'','2018-08-15 09:28:01',0),(249,47,'Issue',1,'','2018-08-15 09:28:08',0),(250,49,'Issue',1,'','2018-08-15 09:28:45',0),(251,50,'Issue',1,'','2018-08-15 09:28:53',0),(252,4,'Issue',1,'','2018-08-15 09:31:39',0),(253,6,'Issue',1,'','2018-08-15 09:31:51',0),(254,10,'Issue',1,'','2018-08-15 09:31:59',0),(255,11,'Issue',1,'','2018-08-15 09:32:10',0),(256,13,'Issue',1,'','2018-08-15 09:32:17',0),(257,18,'Issue',1,'','2018-08-15 09:32:28',0),(258,19,'Issue',1,'','2018-08-15 09:32:34',0),(259,20,'Issue',1,'','2018-08-15 09:32:40',0),(260,21,'Issue',1,'','2018-08-15 09:32:47',0),(261,22,'Issue',1,'','2018-08-15 09:33:23',0),(262,24,'Issue',1,'','2018-08-15 09:35:06',0),(263,25,'Issue',1,'','2018-08-15 09:35:21',0),(264,26,'Issue',1,'','2018-08-15 09:35:32',0),(265,31,'Issue',1,'','2018-08-15 09:36:18',0),(266,34,'Issue',1,'','2018-08-15 09:36:27',0),(267,35,'Issue',1,'','2018-08-15 09:36:39',0),(268,36,'Issue',1,'','2018-08-15 09:36:48',0),(269,37,'Issue',1,'','2018-08-15 09:36:56',0),(270,44,'Issue',1,'','2018-08-15 09:37:24',0),(271,46,'Issue',1,'','2018-08-15 09:37:37',0),(272,47,'Issue',1,'','2018-08-15 09:37:54',0),(279,12,'Issue',1,'','2018-08-15 10:02:08',0),(295,79,'Issue',1,'','2018-08-17 08:27:30',0),(296,80,'Issue',1,'','2018-08-17 08:27:41',0),(297,78,'Issue',1,'','2018-08-17 08:27:49',0),(298,83,'Issue',1,'','2018-08-17 08:30:17',0),(299,83,'Issue',1,'','2018-08-17 08:33:34',0),(300,82,'Issue',1,'','2018-08-17 08:34:45',0),(301,81,'Issue',1,'','2018-08-17 08:34:59',0),(302,85,'Issue',1,'','2018-08-17 08:36:41',0),(303,80,'Issue',1,'','2018-08-17 08:42:58',0),(304,79,'Issue',1,'','2018-08-17 08:42:58',0),(305,82,'Issue',1,'','2018-08-17 08:44:36',0),(306,80,'Issue',1,'','2018-08-17 08:44:36',0),(307,83,'Issue',1,'','2018-08-17 08:44:53',0),(308,82,'Issue',1,'','2018-08-17 08:44:53',0),(309,84,'Issue',1,'','2018-08-17 08:45:12',0),(310,83,'Issue',1,'','2018-08-17 08:45:12',0),(311,85,'Issue',1,'','2018-08-17 08:45:25',0),(312,84,'Issue',1,'','2018-08-17 08:45:25',0),(313,85,'Issue',1,'','2018-08-20 10:16:35',0),(314,85,'Issue',1,'','2018-08-20 10:16:48',0),(333,4,'Issue',1,'','2018-08-20 14:04:48',0),(334,6,'Issue',1,'','2018-08-20 14:05:22',0),(335,10,'Issue',1,'','2018-08-20 14:05:52',0),(336,10,'Issue',1,'','2018-08-20 14:09:01',0),(337,11,'Issue',1,'','2018-08-20 14:09:01',0),(338,11,'Issue',1,'','2018-08-20 14:09:13',0),(339,12,'Issue',1,'','2018-08-20 14:10:00',0),(340,13,'Issue',1,'','2018-08-20 14:10:38',0),(341,18,'Issue',1,'','2018-08-20 14:11:31',0),(342,19,'Issue',1,'','2018-08-20 14:12:48',0),(343,20,'Issue',1,'','2018-08-20 14:13:30',0),(344,21,'Issue',1,'','2018-08-20 14:14:02',0),(345,22,'Issue',1,'','2018-08-20 14:15:09',0),(346,24,'Issue',1,'','2018-08-20 14:18:38',0),(396,112,'Issue',1,'','2018-08-21 09:40:44',0),(397,112,'Issue',1,'','2018-08-21 09:40:53',0),(398,112,'Issue',1,'Transição de status aplicada automaticamente devido ao início do time tracker.','2018-08-21 09:41:43',0),(399,112,'Issue',1,'','2018-08-21 10:09:03',0),(400,111,'Issue',1,'','2018-08-21 10:09:04',0),(401,113,'Issue',1,'','2018-08-21 10:09:07',0),(402,114,'Issue',1,'','2018-08-21 10:09:09',0),(403,114,'Issue',1,'','2018-08-21 10:09:12',0),(404,116,'Issue',1,'','2018-08-21 10:09:41',0),(405,117,'Issue',1,'','2018-08-21 10:09:45',0),(406,119,'Issue',1,'','2018-08-21 10:10:28',0),(407,120,'Issue',1,'','2018-08-21 10:10:32',0),(408,121,'Issue',1,'','2018-08-21 10:10:34',0),(409,122,'Issue',1,'','2018-08-21 10:10:39',0),(410,123,'Issue',1,'','2018-08-21 10:10:49',0),(411,125,'Issue',1,'','2018-08-21 10:11:11',0),(412,128,'Issue',1,'','2018-08-21 10:11:28',0),(413,129,'Issue',1,'','2018-08-21 10:11:30',0),(414,126,'Issue',1,'','2018-08-21 10:12:10',0),(415,127,'Issue',1,'','2018-08-21 10:12:21',0),(416,114,'Issue',1,'','2018-08-21 10:12:36',0);
/*!40000 ALTER TABLE `journals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_roles`
--

DROP TABLE IF EXISTS `member_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `inherited_from` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_member_roles_on_member_id` (`member_id`),
  KEY `index_member_roles_on_role_id` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_roles`
--

LOCK TABLES `member_roles` WRITE;
/*!40000 ALTER TABLE `member_roles` DISABLE KEYS */;
INSERT INTO `member_roles` VALUES (2,2,4,NULL),(3,3,4,NULL),(4,4,4,NULL),(5,5,4,NULL),(6,6,4,NULL),(7,7,4,NULL),(8,8,4,NULL),(9,9,3,NULL),(11,3,3,9),(12,9,4,NULL),(14,3,4,12),(15,9,5,NULL),(17,3,5,15),(18,10,4,NULL),(19,11,4,NULL),(22,14,4,NULL),(23,15,4,NULL),(26,18,4,NULL),(27,17,6,NULL);
/*!40000 ALTER TABLE `member_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `project_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `mail_notification` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_members_on_user_id_and_project_id` (`user_id`,`project_id`),
  KEY `index_members_on_user_id` (`user_id`),
  KEY `index_members_on_project_id` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members`
--

LOCK TABLES `members` WRITE;
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
INSERT INTO `members` VALUES (2,5,2,'2018-08-14 08:03:44',0),(3,6,2,'2018-08-14 09:06:00',0),(4,8,1,'2018-08-14 13:18:12',0),(5,7,1,'2018-08-14 13:18:12',0),(6,11,1,'2018-08-14 13:18:12',0),(7,9,1,'2018-08-14 13:18:12',0),(8,10,1,'2018-08-14 13:18:12',0),(9,12,2,'2018-08-15 08:14:14',0),(10,13,2,'2018-08-17 08:13:36',0),(11,8,5,'2018-08-20 14:56:17',0),(14,11,5,'2018-08-20 14:56:17',0),(15,10,5,'2018-08-20 14:56:17',0),(17,7,5,'2018-08-20 14:56:27',0),(18,9,5,'2018-08-20 14:56:53',0);
/*!40000 ALTER TABLE `members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `board_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `content` text,
  `author_id` int(11) DEFAULT NULL,
  `replies_count` int(11) NOT NULL DEFAULT '0',
  `last_reply_id` int(11) DEFAULT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `locked` tinyint(1) DEFAULT '0',
  `sticky` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `messages_board_id` (`board_id`),
  KEY `messages_parent_id` (`parent_id`),
  KEY `index_messages_on_last_reply_id` (`last_reply_id`),
  KEY `index_messages_on_author_id` (`author_id`),
  KEY `index_messages_on_created_on` (`created_on`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `title` varchar(60) NOT NULL DEFAULT '',
  `summary` varchar(255) DEFAULT '',
  `description` text,
  `author_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `comments_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `news_project_id` (`project_id`),
  KEY `index_news_on_author_id` (`author_id`),
  KEY `index_news_on_created_on` (`created_on`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news`
--

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `open_id_authentication_associations`
--

DROP TABLE IF EXISTS `open_id_authentication_associations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_id_authentication_associations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `issued` int(11) DEFAULT NULL,
  `lifetime` int(11) DEFAULT NULL,
  `handle` varchar(255) DEFAULT NULL,
  `assoc_type` varchar(255) DEFAULT NULL,
  `server_url` blob,
  `secret` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_id_authentication_associations`
--

LOCK TABLES `open_id_authentication_associations` WRITE;
/*!40000 ALTER TABLE `open_id_authentication_associations` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_id_authentication_associations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `open_id_authentication_nonces`
--

DROP TABLE IF EXISTS `open_id_authentication_nonces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_id_authentication_nonces` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` int(11) NOT NULL,
  `server_url` varchar(255) DEFAULT NULL,
  `salt` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_id_authentication_nonces`
--

LOCK TABLES `open_id_authentication_nonces` WRITE;
/*!40000 ALTER TABLE `open_id_authentication_nonces` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_id_authentication_nonces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `people_announcements`
--

DROP TABLE IF EXISTS `people_announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `people_announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `frequency` varchar(255) DEFAULT NULL,
  `kind` varchar(255) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `people_announcements`
--

LOCK TABLES `people_announcements` WRITE;
/*!40000 ALTER TABLE `people_announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `people_announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `people_holidays`
--

DROP TABLE IF EXISTS `people_holidays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `people_holidays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `description` text,
  `is_workday` tinyint(1) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `people_holidays`
--

LOCK TABLES `people_holidays` WRITE;
/*!40000 ALTER TABLE `people_holidays` DISABLE KEYS */;
/*!40000 ALTER TABLE `people_holidays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `people_information`
--

DROP TABLE IF EXISTS `people_information`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `people_information` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `skype` varchar(255) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `job_title` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `middlename` varchar(255) DEFAULT NULL,
  `gender` tinyint(4) DEFAULT NULL,
  `twitter` varchar(255) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `linkedin` varchar(255) DEFAULT NULL,
  `background` text,
  `appearance_date` date DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL,
  `is_system` tinyint(1) DEFAULT '0',
  `manager_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `people_information`
--

LOCK TABLES `people_information` WRITE;
/*!40000 ALTER TABLE `people_information` DISABLE KEYS */;
INSERT INTO `people_information` VALUES (1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL),(5,'','','',NULL,'Estagiário(a)',NULL,'',0,'','','','',NULL,NULL,0,7),(6,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL),(7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL),(8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL),(9,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL),(10,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL),(11,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL),(13,'','','',NULL,'Estagiário(a)',NULL,'',1,'','','','',NULL,NULL,0,7);
/*!40000 ALTER TABLE `people_information` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `people_work_experiences`
--

DROP TABLE IF EXISTS `people_work_experiences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `people_work_experiences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `previous_company_name` varchar(255) DEFAULT NULL,
  `job_title` varchar(255) DEFAULT NULL,
  `from_date` datetime DEFAULT NULL,
  `to_date` datetime DEFAULT NULL,
  `description` text,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_people_work_experiences_on_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `people_work_experiences`
--

LOCK TABLES `people_work_experiences` WRITE;
/*!40000 ALTER TABLE `people_work_experiences` DISABLE KEYS */;
/*!40000 ALTER TABLE `people_work_experiences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `homepage` varchar(255) DEFAULT '',
  `is_public` tinyint(1) NOT NULL DEFAULT '1',
  `parent_id` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `lft` int(11) DEFAULT NULL,
  `rgt` int(11) DEFAULT NULL,
  `inherit_members` tinyint(1) NOT NULL DEFAULT '0',
  `default_version_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_projects_on_lft` (`lft`),
  KEY `index_projects_on_rgt` (`rgt`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES (1,'GOVERNANÇA DE TI','','',1,3,'2018-08-09 14:36:55','2018-08-16 12:29:20','governanca-de-ti',5,6,7,0,NULL),(2,'CUSTOMIZAÇÃO REDMINE','','',1,NULL,'2018-08-14 08:02:13','2018-08-16 12:28:29','customizacao-redmine',1,1,2,0,NULL),(3,'PMO QUALIDADE','','',1,NULL,'2018-08-16 12:28:58','2018-08-16 12:28:58','pmo-qualidade',1,3,8,0,NULL),(4,'TESTE','','',1,NULL,'2018-08-20 10:44:55','2018-08-20 10:44:55','teste',5,9,10,0,NULL),(5,'Governança de TI','','www.grupoelfa.com.br',1,3,'2018-08-20 14:55:38','2018-08-20 14:55:38','governanca-de-ti-333',1,4,5,0,NULL);
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects_trackers`
--

DROP TABLE IF EXISTS `projects_trackers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projects_trackers` (
  `project_id` int(11) NOT NULL DEFAULT '0',
  `tracker_id` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `projects_trackers_unique` (`project_id`,`tracker_id`),
  KEY `projects_trackers_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects_trackers`
--

LOCK TABLES `projects_trackers` WRITE;
/*!40000 ALTER TABLE `projects_trackers` DISABLE KEYS */;
INSERT INTO `projects_trackers` VALUES (1,1),(1,2),(1,3),(2,1),(2,2),(2,3),(3,1),(3,2),(3,3),(4,1),(4,2),(4,3),(5,1),(5,2),(5,3);
/*!40000 ALTER TABLE `projects_trackers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queries`
--

DROP TABLE IF EXISTS `queries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `filters` text,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `column_names` text,
  `sort_criteria` text,
  `group_by` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `visibility` int(11) DEFAULT '0',
  `options` text,
  PRIMARY KEY (`id`),
  KEY `index_queries_on_project_id` (`project_id`),
  KEY `index_queries_on_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queries`
--

LOCK TABLES `queries` WRITE;
/*!40000 ALTER TABLE `queries` DISABLE KEYS */;
INSERT INTO `queries` VALUES (1,5,'a','---\nstatus_id:\n  :operator: o\n  :values:\n  - \'\'\n',1,NULL,NULL,'status','IssueQuery',0,'---\n:totalable_names: []\n:draw_relations: \n:draw_progress_line: \n');
/*!40000 ALTER TABLE `queries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queries_roles`
--

DROP TABLE IF EXISTS `queries_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queries_roles` (
  `query_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  UNIQUE KEY `queries_roles_ids` (`query_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queries_roles`
--

LOCK TABLES `queries_roles` WRITE;
/*!40000 ALTER TABLE `queries_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `queries_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repositories`
--

DROP TABLE IF EXISTS `repositories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repositories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL DEFAULT '',
  `login` varchar(60) DEFAULT '',
  `password` varchar(255) DEFAULT '',
  `root_url` varchar(255) DEFAULT '',
  `type` varchar(255) DEFAULT NULL,
  `path_encoding` varchar(64) DEFAULT NULL,
  `log_encoding` varchar(64) DEFAULT NULL,
  `extra_info` text,
  `identifier` varchar(255) DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_repositories_on_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repositories`
--

LOCK TABLES `repositories` WRITE;
/*!40000 ALTER TABLE `repositories` DISABLE KEYS */;
/*!40000 ALTER TABLE `repositories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `position` int(11) DEFAULT NULL,
  `assignable` tinyint(1) DEFAULT '1',
  `builtin` int(11) NOT NULL DEFAULT '0',
  `permissions` text,
  `issues_visibility` varchar(30) NOT NULL DEFAULT 'default',
  `users_visibility` varchar(30) NOT NULL DEFAULT 'all',
  `time_entries_visibility` varchar(30) NOT NULL DEFAULT 'all',
  `all_roles_managed` tinyint(1) NOT NULL DEFAULT '1',
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Non member',0,1,1,'---\n- :view_issues\n- :add_issues\n- :add_issue_notes\n- :save_queries\n- :view_gantt\n- :view_calendar\n- :view_time_entries\n- :comment_news\n- :view_documents\n- :view_wiki_pages\n- :view_wiki_edits\n- :add_messages\n- :view_files\n- :browse_repository\n- :view_changesets\n','default','all','all',1,NULL),(2,'Anonymous',0,1,2,'---\n- :view_issues\n- :view_gantt\n- :view_calendar\n- :view_time_entries\n- :view_documents\n- :view_wiki_pages\n- :view_wiki_edits\n- :view_files\n- :browse_repository\n- :view_changesets\n','default','all','all',1,NULL),(3,'PMO',1,1,0,'---\n- :add_project\n- :edit_project\n- :close_project\n- :select_project_modules\n- :manage_members\n- :manage_versions\n- :add_subprojects\n- :view_agile_queries\n- :view_agile_charts\n- :add_messages\n- :edit_messages\n- :edit_own_messages\n- :delete_messages\n- :delete_own_messages\n- :manage_boards\n- :view_calendar\n- :view_documents\n- :add_documents\n- :edit_documents\n- :delete_documents\n- :view_easy_gantt\n- :edit_easy_gantt\n- :view_global_easy_gantt\n- :edit_global_easy_gantt\n- :view_personal_easy_gantt\n- :edit_personal_easy_gantt\n- :view_files\n- :manage_files\n- :view_gantt\n- :view_issues\n- :add_issues\n- :edit_issues\n- :copy_issues\n- :manage_issue_relations\n- :manage_subtasks\n- :set_issues_private\n- :set_own_issues_private\n- :add_issue_notes\n- :edit_issue_notes\n- :edit_own_issue_notes\n- :view_private_notes\n- :set_notes_private\n- :delete_issues\n- :manage_public_queries\n- :save_queries\n- :view_issue_watchers\n- :add_issue_watchers\n- :delete_issue_watchers\n- :import_issues\n- :manage_categories\n- :manage_news\n- :comment_news\n- :view_changesets\n- :browse_repository\n- :commit_access\n- :manage_related_issues\n- :manage_repository\n- :view_time_entries\n- :log_time\n- :edit_time_entries\n- :edit_own_time_entries\n- :manage_project_activities\n- :view_wiki_pages\n- :view_wiki_edits\n- :export_wiki_pages\n- :edit_wiki_pages\n- :rename_wiki_pages\n- :delete_wiki_pages\n- :delete_wiki_pages_attachments\n- :protect_wiki_pages\n- :manage_wiki\n','all','all','all',0,'--- !ruby/hash:ActiveSupport::HashWithIndifferentAccess\npermissions_all_trackers: !ruby/hash:ActiveSupport::HashWithIndifferentAccess\n  view_issues: \'1\'\n  add_issues: \'1\'\n  edit_issues: \'1\'\n  add_issue_notes: \'1\'\n  delete_issues: \'1\'\npermissions_tracker_ids: !ruby/hash:ActiveSupport::HashWithIndifferentAccess\n  view_issues: []\n  add_issues: []\n  edit_issues: []\n  add_issue_notes: []\n  delete_issues: []\n'),(4,'Colaborador interno',2,1,0,'---\n- :view_agile_queries\n- :view_agile_charts\n- :add_messages\n- :edit_own_messages\n- :view_calendar\n- :view_documents\n- :view_easy_gantt\n- :view_global_easy_gantt\n- :view_personal_easy_gantt\n- :view_easy_wbs\n- :edit_easy_wbs\n- :view_files\n- :manage_files\n- :view_gantt\n- :view_issues\n- :edit_issues\n- :add_issue_notes\n- :comment_news\n- :view_changesets\n- :browse_repository\n- :commit_access\n- :manage_related_issues\n- :view_time_entries\n- :log_time\n- :view_wiki_pages\n- :view_wiki_edits\n- :edit_wiki_pages\n- :delete_wiki_pages\n','default','all','all',1,'--- !ruby/hash:ActiveSupport::HashWithIndifferentAccess\npermissions_all_trackers: !ruby/hash:ActiveSupport::HashWithIndifferentAccess\n  view_issues: \'1\'\n  add_issues: \'1\'\n  edit_issues: \'0\'\n  add_issue_notes: \'1\'\n  delete_issues: \'1\'\npermissions_tracker_ids: !ruby/hash:ActiveSupport::HashWithIndifferentAccess\n  view_issues: []\n  add_issues: []\n  edit_issues: []\n  add_issue_notes: []\n  delete_issues: []\n'),(5,'Colaborador externo',3,1,0,'---\n- :add_messages\n- :edit_own_messages\n- :view_calendar\n- :view_documents\n- :view_files\n- :view_gantt\n- :view_issues\n- :comment_news\n- :view_changesets\n- :browse_repository\n- :view_time_entries\n- :log_time\n- :view_wiki_pages\n- :view_wiki_edits\n','default','all','all',1,'--- !ruby/hash:ActiveSupport::HashWithIndifferentAccess\npermissions_all_trackers: !ruby/hash:ActiveSupport::HashWithIndifferentAccess\n  view_issues: \'1\'\n  add_issues: \'1\'\n  edit_issues: \'1\'\n  add_issue_notes: \'1\'\n  delete_issues: \'1\'\npermissions_tracker_ids: !ruby/hash:ActiveSupport::HashWithIndifferentAccess\n  view_issues: []\n  add_issues: []\n  edit_issues: []\n  add_issue_notes: []\n  delete_issues: []\n'),(6,'Dono(a)',4,1,0,'---\n- :manage_members\n- :view_others_time_loggers\n- :view_agile_queries\n- :view_agile_charts\n- :add_messages\n- :edit_own_messages\n- :view_calendar\n- :view_documents\n- :add_documents\n- :view_easy_gantt\n- :view_global_easy_gantt\n- :view_personal_easy_gantt\n- :view_easy_wbs\n- :view_files\n- :view_gantt\n- :view_issues\n- :add_issues\n- :edit_issues\n- :set_own_issues_private\n- :add_issue_notes\n- :manage_public_queries\n- :save_queries\n- :comment_news\n- :view_changesets\n- :browse_repository\n- :view_time_entries\n- :log_time\n- :edit_own_time_entries\n- :view_wiki_pages\n- :view_wiki_edits\n','default','all','all',1,'--- !ruby/hash:ActiveSupport::HashWithIndifferentAccess\npermissions_all_trackers: !ruby/hash:ActiveSupport::HashWithIndifferentAccess\n  view_issues: \'1\'\n  add_issues: \'1\'\n  edit_issues: \'1\'\n  add_issue_notes: \'1\'\n  delete_issues: \'1\'\npermissions_tracker_ids: !ruby/hash:ActiveSupport::HashWithIndifferentAccess\n  view_issues: []\n  add_issues: []\n  edit_issues: []\n  add_issue_notes: []\n  delete_issues: []\n');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles_managed_roles`
--

DROP TABLE IF EXISTS `roles_managed_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles_managed_roles` (
  `role_id` int(11) NOT NULL,
  `managed_role_id` int(11) NOT NULL,
  UNIQUE KEY `index_roles_managed_roles_on_role_id_and_managed_role_id` (`role_id`,`managed_role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles_managed_roles`
--

LOCK TABLES `roles_managed_roles` WRITE;
/*!40000 ALTER TABLE `roles_managed_roles` DISABLE KEYS */;
INSERT INTO `roles_managed_roles` VALUES (3,3);
/*!40000 ALTER TABLE `roles_managed_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_migrations` (
  `version` varchar(255) NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_migrations`
--

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` VALUES ('1'),('1-mega_calendar'),('1-redmine_agile'),('1-redmine_gamification_plugin'),('1-redmine_people'),('1-time_logger'),('10'),('10-redmine_people'),('100'),('101'),('102'),('103'),('104'),('105'),('106'),('107'),('108'),('11'),('11-redmine_people'),('12'),('12-redmine_people'),('13'),('13-redmine_people'),('14'),('15'),('16'),('17'),('18'),('19'),('2'),('2-mega_calendar'),('2-redmine_agile'),('2-redmine_gamification_plugin'),('2-redmine_people'),('20'),('20090214190337'),('20090312172426'),('20090312194159'),('20090318181151'),('20090323224724'),('20090401221305'),('20090401231134'),('20090403001910'),('20090406161854'),('20090425161243'),('20090503121501'),('20090503121505'),('20090503121510'),('20090614091200'),('20090704172350'),('20090704172355'),('20090704172358'),('20091010093521'),('20091017212227'),('20091017212457'),('20091017212644'),('20091017212938'),('20091017213027'),('20091017213113'),('20091017213151'),('20091017213228'),('20091017213257'),('20091017213332'),('20091017213444'),('20091017213536'),('20091017213642'),('20091017213716'),('20091017213757'),('20091017213835'),('20091017213910'),('20091017214015'),('20091017214107'),('20091017214136'),('20091017214236'),('20091017214308'),('20091017214336'),('20091017214406'),('20091017214440'),('20091017214519'),('20091017214611'),('20091017214644'),('20091017214720'),('20091017214750'),('20091025163651'),('20091108092559'),('20091114105931'),('20091123212029'),('20091205124427'),('20091220183509'),('20091220183727'),('20091220184736'),('20091225164732'),('20091227112908'),('20100129193402'),('20100129193813'),('20100221100219'),('20100313132032'),('20100313171051'),('20100705164950'),('20100819172912'),('20101104182107'),('20101107130441'),('20101114115114'),('20101114115359'),('20110220160626'),('20110223180944'),('20110223180953'),('20110224000000'),('20110226120112'),('20110226120132'),('20110227125750'),('20110228000000'),('20110228000100'),('20110401192910'),('20110408103312'),('20110412065600'),('20110511000000'),('20110902000000'),('20111201201315'),('20120115143024'),('20120115143100'),('20120115143126'),('20120127174243'),('20120205111326'),('20120223110929'),('20120301153455'),('20120422150750'),('20120705074331'),('20120707064544'),('20120714122000'),('20120714122100'),('20120714122200'),('20120731164049'),('20120930112914'),('20121026002032'),('20121026003537'),('20121209123234'),('20121209123358'),('20121213084931'),('20130110122628'),('20130201184705'),('20130202090625'),('20130207175206'),('20130207181455'),('20130215073721'),('20130215111127'),('20130215111141'),('20130217094251'),('20130602092539'),('20130710182539'),('20130713104233'),('20130713111657'),('20130729070143'),('20130911193200'),('20131004113137'),('20131005100610'),('20131124175346'),('20131210180802'),('20131214094309'),('20131215104612'),('20131218183023'),('20140228130325'),('20140903143914'),('20140920094058'),('20141029181752'),('20141029181824'),('20141109112308'),('20141122124142'),('20150113194759'),('20150113211532'),('20150113213922'),('20150113213955'),('20150208105930'),('20150510083747'),('20150525103953'),('20150526183158'),('20150528084820'),('20150528092912'),('20150528093249'),('20150705172511'),('20150725112753'),('20150730122707'),('20150730122735'),('20150921204850'),('20150921210243'),('20151020182334'),('20151020182731'),('20151021184614'),('20151021185456'),('20151021190616'),('20151024082034'),('20151025072118'),('20151031095005'),('20160404080304'),('20160416072926'),('20160519161300'),('20160529063352'),('20170213152215-easy_gantt'),('20170224134615-easy_gantt'),('21'),('22'),('23'),('24'),('25'),('26'),('27'),('28'),('29'),('3'),('3-mega_calendar'),('3-redmine_agile'),('3-redmine_gamification_plugin'),('3-redmine_people'),('30'),('31'),('32'),('33'),('34'),('35'),('36'),('37'),('38'),('39'),('4'),('4-mega_calendar'),('4-redmine_agile'),('4-redmine_gamification_plugin'),('4-redmine_people'),('40'),('41'),('42'),('43'),('44'),('45'),('46'),('47'),('48'),('49'),('5'),('5-redmine_agile'),('5-redmine_gamification_plugin'),('5-redmine_people'),('50'),('51'),('52'),('53'),('54'),('55'),('56'),('57'),('58'),('59'),('6'),('6-redmine_gamification_plugin'),('6-redmine_people'),('60'),('61'),('62'),('63'),('64'),('65'),('66'),('67'),('68'),('69'),('7'),('7-redmine_gamification_plugin'),('7-redmine_people'),('70'),('71'),('72'),('73'),('74'),('75'),('76'),('77'),('78'),('79'),('8'),('8-redmine_gamification_plugin'),('8-redmine_people'),('80'),('81'),('82'),('83'),('84'),('85'),('86'),('87'),('88'),('89'),('9'),('9-redmine_gamification_plugin'),('9-redmine_people'),('90'),('91'),('92'),('93'),('94'),('95'),('96'),('97'),('98'),('99');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `value` text,
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_settings_on_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'ui_theme','circle','2018-08-16 14:05:36'),(2,'default_language','pt-BR','2018-08-09 14:34:30'),(3,'force_default_language_for_anonymous','0','2018-08-09 14:34:30'),(4,'force_default_language_for_loggedin','0','2018-08-09 14:34:30'),(5,'start_of_week','','2018-08-09 14:34:30'),(6,'date_format','','2018-08-09 14:34:30'),(7,'time_format','','2018-08-09 14:34:30'),(8,'user_format','firstname_lastname','2018-08-09 14:34:30'),(9,'gravatar_enabled','0','2018-08-09 14:34:30'),(10,'gravatar_default','','2018-08-09 14:34:30'),(11,'thumbnails_enabled','0','2018-08-09 14:34:30'),(12,'thumbnails_size','100','2018-08-09 14:34:30'),(13,'new_item_menu_tab','2','2018-08-09 14:34:30'),(14,'plugin_time_logger','--- !ruby/hash-with-ivars:ActionController::Parameters\nelements:\n  refresh_rate: \'60\'\n  status_transitions: !ruby/hash-with-ivars:ActionController::Parameters\n    elements:\n      \'1\': \'2\'\n    ivars:\n      :@permitted: false\nivars:\n  :@permitted: false\n','2018-08-15 08:47:14'),(15,'rest_api_enabled','1','2018-08-09 14:54:31'),(16,'jsonp_enabled','0','2018-08-09 14:54:31'),(17,'login_required','1','2018-08-10 10:15:13'),(18,'autologin','0','2018-08-10 10:15:13'),(19,'self_registration','2','2018-08-10 10:15:13'),(20,'unsubscribe','1','2018-08-10 10:15:13'),(21,'password_min_length','8','2018-08-10 10:15:13'),(22,'password_max_age','0','2018-08-10 10:15:13'),(23,'lost_password','1','2018-08-10 10:15:13'),(24,'max_additional_emails','5','2018-08-10 10:15:13'),(25,'openid','0','2018-08-10 10:15:13'),(26,'session_lifetime','0','2018-08-10 10:15:13'),(27,'session_timeout','0','2018-08-10 10:15:13'),(28,'default_users_hide_mail','1','2018-08-10 10:15:13'),(29,'cross_project_issue_relations','0','2018-08-10 11:54:19'),(30,'link_copied_issue','ask','2018-08-10 10:31:34'),(31,'cross_project_subtasks','tree','2018-08-10 10:30:50'),(32,'issue_group_assignment','0','2018-08-10 10:30:50'),(33,'default_issue_start_date_to_creation_date','1','2018-08-10 10:30:50'),(34,'display_subprojects_issues','1','2018-08-10 10:30:50'),(35,'issue_done_ratio','issue_field','2018-08-20 10:17:00'),(36,'non_working_week_days','---\n- \'6\'\n- \'7\'\n','2018-08-20 10:19:54'),(37,'issues_export_limit','500','2018-08-10 10:30:50'),(38,'gantt_items_limit','500','2018-08-10 10:30:50'),(39,'parent_issue_dates','derived','2018-08-10 10:30:50'),(40,'parent_issue_priority','derived','2018-08-10 10:30:50'),(41,'parent_issue_done_ratio','derived','2018-08-10 10:30:50'),(42,'issue_list_default_columns','---\n- tracker\n- status\n- priority\n- subject\n- assigned_to\n- updated_on\n','2018-08-10 10:30:50'),(43,'issue_list_default_totals','--- []\n','2018-08-10 10:30:50'),(44,'default_projects_public','1','2018-08-13 08:41:52'),(45,'default_projects_modules','---\n- issue_tracking\n- time_tracking\n- documents\n- files\n- boards\n- calendar\n- easy_wbs\n- agile\n- easy_gantt\n','2018-08-21 10:44:58'),(46,'default_projects_tracker_ids','---\n- \'1\'\n- \'2\'\n- \'3\'\n','2018-08-20 10:20:22'),(47,'sequential_project_identifiers','0','2018-08-13 08:41:52'),(48,'app_title','Emine','2018-08-20 11:47:47'),(49,'welcome_text','','2018-08-20 11:47:47'),(50,'per_page_options','25,50,100','2018-08-20 11:47:48'),(51,'search_results_per_page','10','2018-08-20 11:47:48'),(52,'activity_days_default','30','2018-08-20 11:47:48'),(53,'host_name','localhost:3000','2018-08-20 11:47:48'),(54,'protocol','http','2018-08-20 11:47:48'),(55,'text_formatting','textile','2018-08-20 11:47:48'),(56,'cache_formatted_text','0','2018-08-20 11:47:48'),(57,'wiki_compression','','2018-08-20 11:47:48'),(58,'feeds_limit','15','2018-08-20 11:47:48');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggings`
--

DROP TABLE IF EXISTS `taggings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag_id` int(11) DEFAULT NULL,
  `taggable_id` int(11) DEFAULT NULL,
  `taggable_type` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_taggings_on_tag_id` (`tag_id`),
  KEY `index_taggings_on_taggable_id_and_taggable_type` (`taggable_id`,`taggable_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggings`
--

LOCK TABLES `taggings` WRITE;
/*!40000 ALTER TABLE `taggings` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_times`
--

DROP TABLE IF EXISTS `ticket_times`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_times` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time_begin` time DEFAULT NULL,
  `time_end` time DEFAULT NULL,
  `issue_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_times`
--

LOCK TABLES `ticket_times` WRITE;
/*!40000 ALTER TABLE `ticket_times` DISABLE KEYS */;
INSERT INTO `ticket_times` VALUES (1,'10:00:00','17:00:00',86),(2,'10:00:00','15:00:00',87);
/*!40000 ALTER TABLE `ticket_times` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `time_entries`
--

DROP TABLE IF EXISTS `time_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `time_entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `issue_id` int(11) DEFAULT NULL,
  `hours` float NOT NULL,
  `comments` varchar(1024) DEFAULT NULL,
  `activity_id` int(11) NOT NULL,
  `spent_on` date NOT NULL,
  `tyear` int(11) NOT NULL,
  `tmonth` int(11) NOT NULL,
  `tweek` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `time_entries_project_id` (`project_id`),
  KEY `time_entries_issue_id` (`issue_id`),
  KEY `index_time_entries_on_activity_id` (`activity_id`),
  KEY `index_time_entries_on_user_id` (`user_id`),
  KEY `index_time_entries_on_created_on` (`created_on`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `time_entries`
--

LOCK TABLES `time_entries` WRITE;
/*!40000 ALTER TABLE `time_entries` DISABLE KEYS */;
INSERT INTO `time_entries` VALUES (1,1,1,1,0,'',9,'2018-08-09',2018,8,32,'2018-08-09 14:39:59','2018-08-09 14:39:59'),(2,1,5,4,1,'',9,'2018-08-10',2018,8,32,'2018-08-10 11:09:42','2018-08-10 11:09:42'),(3,1,5,6,10,'',9,'2018-08-10',2018,8,32,'2018-08-10 11:23:47','2018-08-10 11:23:47'),(4,1,1,4,0.01,'',9,'2018-08-10',2018,8,32,'2018-08-10 12:36:57','2018-08-10 12:36:57');
/*!40000 ALTER TABLE `time_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `time_loggers`
--

DROP TABLE IF EXISTS `time_loggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `time_loggers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `issue_id` int(11) DEFAULT NULL,
  `started_on` datetime DEFAULT NULL,
  `time_spent` float DEFAULT '0',
  `paused` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `time_loggers`
--

LOCK TABLES `time_loggers` WRITE;
/*!40000 ALTER TABLE `time_loggers` DISABLE KEYS */;
/*!40000 ALTER TABLE `time_loggers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `action` varchar(30) NOT NULL DEFAULT '',
  `value` varchar(40) NOT NULL DEFAULT '',
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tokens_value` (`value`),
  KEY `index_tokens_on_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
INSERT INTO `tokens` VALUES (2,1,'session','e18ed30dd2ab48a66369486ff8704e1d7baaf3ad','2018-08-09 14:34:12','2018-08-09 16:34:01'),(3,1,'feeds','a561c320c20105b60b184a8cc8aaedf6365ed708','2018-08-09 14:34:14','2018-08-09 14:34:14'),(4,1,'api','be1311402db5a62be389d988e85aee5b0cf003a9','2018-08-09 14:54:40','2018-08-09 14:54:40'),(8,5,'feeds','d6a12317c9d27c89f2b7a9718f9c0571de14c91b','2018-08-10 11:03:34','2018-08-10 11:03:34'),(10,5,'session','a670fa1e45c411f2e1e2cefab496c8cf8e7e3961','2018-08-10 11:09:03','2018-08-10 13:04:24'),(11,5,'api','9b6e344d3d8226c8e13cdc4b2bb5afeca73b99cb','2018-08-10 11:25:03','2018-08-10 11:25:03'),(12,1,'session','c009cf3b2cbcef569f0b312d25929bcfed58fe0c','2018-08-10 13:07:21','2018-08-10 13:39:22'),(13,1,'session','5c13e4367ab082d27146e63148f6c688eac88e10','2018-08-13 08:23:55','2018-08-13 15:00:39'),(15,5,'session','91166d5ae888b22b3353a67940f28e87eae9f673','2018-08-14 08:06:43','2018-08-14 08:07:29'),(16,1,'session','75afc3ede4d9bbd1b57d452d6310cfceffd8f64f','2018-08-15 08:00:11','2018-08-15 08:18:20'),(18,6,'session','3bb671bb3ce8c9eca3f147d16417e6e7d2fd8c1f','2018-08-15 08:09:12','2018-08-15 08:18:25'),(19,6,'feeds','6dc4bfba47d0ef0610c56fab046c6883d1dc5796','2018-08-15 08:09:13','2018-08-15 08:09:13'),(20,1,'session','6708d14972743f62528c7c87dce55766f0b77aa5','2018-08-15 08:19:12','2018-08-15 10:21:39'),(21,6,'session','2c4079f391075e7fcc4876917d87b49ccbd7dc7c','2018-08-15 08:19:46','2018-08-15 09:19:46'),(22,5,'session','691b5f76fb932892ec69cada2cf8f4535358d231','2018-08-15 09:57:22','2018-08-15 10:21:52'),(23,1,'session','e125f98b3a7f95af82aedd2b74ac24ef1a07c0f0','2018-08-17 08:10:04','2018-08-17 08:53:44'),(29,1,'session','1227a99e4fee53e865400d13830f6660072038df','2018-08-20 13:56:07','2018-08-20 17:26:06'),(30,1,'session','711509f3e62dedebb14e6ca7cf29ffc6785ae21c','2018-08-21 09:20:37','2018-08-21 15:06:21');
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trackers`
--

DROP TABLE IF EXISTS `trackers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trackers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `is_in_chlog` tinyint(1) NOT NULL DEFAULT '0',
  `position` int(11) DEFAULT NULL,
  `is_in_roadmap` tinyint(1) NOT NULL DEFAULT '1',
  `fields_bits` int(11) DEFAULT '0',
  `default_status_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trackers`
--

LOCK TABLES `trackers` WRITE;
/*!40000 ALTER TABLE `trackers` DISABLE KEYS */;
INSERT INTO `trackers` VALUES (1,'Análise ',1,1,0,0,1),(2,'Desenvolvimento',1,2,1,0,1),(3,'Teste',0,3,0,0,1);
/*!40000 ALTER TABLE `trackers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_colors`
--

DROP TABLE IF EXISTS `user_colors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_colors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `color_code` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_colors`
--

LOCK TABLES `user_colors` WRITE;
/*!40000 ALTER TABLE `user_colors` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_colors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_filters`
--

DROP TABLE IF EXISTS `user_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_filters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `filter_name` varchar(255) DEFAULT NULL,
  `filter_code` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_filters`
--

LOCK TABLES `user_filters` WRITE;
/*!40000 ALTER TABLE `user_filters` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_preferences`
--

DROP TABLE IF EXISTS `user_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_preferences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `others` text,
  `hide_mail` tinyint(1) DEFAULT '1',
  `time_zone` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_user_preferences_on_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_preferences`
--

LOCK TABLES `user_preferences` WRITE;
/*!40000 ALTER TABLE `user_preferences` DISABLE KEYS */;
INSERT INTO `user_preferences` VALUES (1,1,'---\n:no_self_notified: true\n:gantt_zoom: 2\n:gantt_months: 6\n',1,NULL),(2,5,'---\n:no_self_notified: \'1\'\n:comments_sorting: asc\n:warn_on_leaving_unsaved: \'1\'\n',1,''),(3,6,'---\n:no_self_notified: \'1\'\n:comments_sorting: asc\n:warn_on_leaving_unsaved: \'1\'\n',1,''),(4,7,'---\n:no_self_notified: \'1\'\n:comments_sorting: asc\n:warn_on_leaving_unsaved: \'1\'\n',1,''),(5,8,'---\n:no_self_notified: \'1\'\n:comments_sorting: asc\n:warn_on_leaving_unsaved: \'1\'\n',1,''),(6,9,'---\n:no_self_notified: \'1\'\n:comments_sorting: asc\n:warn_on_leaving_unsaved: \'1\'\n',1,''),(7,10,'---\n:no_self_notified: \'1\'\n:comments_sorting: asc\n:warn_on_leaving_unsaved: \'1\'\n',1,''),(8,11,'---\n:no_self_notified: \'1\'\n:comments_sorting: asc\n:warn_on_leaving_unsaved: \'1\'\n',1,''),(9,13,'---\n:no_self_notified: false\n',1,NULL);
/*!40000 ALTER TABLE `user_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(255) NOT NULL DEFAULT '',
  `hashed_password` varchar(40) NOT NULL DEFAULT '',
  `firstname` varchar(30) NOT NULL DEFAULT '',
  `lastname` varchar(255) NOT NULL DEFAULT '',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '1',
  `last_login_on` datetime DEFAULT NULL,
  `language` varchar(5) DEFAULT '',
  `auth_source_id` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `identity_url` varchar(255) DEFAULT NULL,
  `mail_notification` varchar(255) NOT NULL DEFAULT '',
  `salt` varchar(64) DEFAULT NULL,
  `must_change_passwd` tinyint(1) NOT NULL DEFAULT '0',
  `passwd_changed_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_users_on_id_and_type` (`id`,`type`),
  KEY `index_users_on_auth_source_id` (`auth_source_id`),
  KEY `index_users_on_type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','d40611ce60c5a8907cfc5c84357f497962123262','Redmine','Admin',1,1,'2018-08-21 09:20:36','',NULL,'2018-08-09 14:30:42','2018-08-09 14:34:12','User',NULL,'all','8d015d7d841e86a12b5290d58011d60b',0,'2018-08-09 14:34:12'),(2,'','','','Anonymous users',0,1,NULL,'',NULL,'2018-08-09 14:32:27','2018-08-09 14:32:27','GroupAnonymous',NULL,'',NULL,0,NULL),(3,'','','','Non member users',0,1,NULL,'',NULL,'2018-08-09 14:32:27','2018-08-09 14:32:27','GroupNonMember',NULL,'',NULL,0,NULL),(4,'','','','Anonymous',0,0,NULL,'',NULL,'2018-08-09 14:33:24','2018-08-09 14:33:24','AnonymousUser',NULL,'only_my_events',NULL,0,NULL),(5,'lucas.barbosa','9fac64cefdfcfcd3c898c830bcfb22b5dfa728c4','Lucas','Barbosa',0,1,'2018-08-17 08:37:29','pt-BR',NULL,'2018-08-09 14:49:46','2018-08-09 14:49:46','User',NULL,'only_my_events','00246edc395967e6f5c784b1d4ca9ff7',0,'2018-08-09 14:49:46'),(6,'thiago.santos','31c382caaecbe3e513df99d8a7daca18db388731','Thiago','Santos',0,1,'2018-08-15 08:19:46','pt-BR',NULL,'2018-08-14 09:05:35','2018-08-15 08:09:06','User',NULL,'only_my_events','12b3f29883fcd8be047e7bb85093a8d6',0,'2018-08-15 08:09:06'),(7,'herbert.ayres','a77351089acf0d697adaf82b564a8915374f092b','Herbert','Ayres',1,1,NULL,'pt-BR',NULL,'2018-08-14 13:14:49','2018-08-14 13:14:49','User',NULL,'only_my_events','12cf2320d4446139bdfb2be43726e9f7',1,'2018-08-14 13:14:49'),(8,'clauber.maia','4398298fe86b23e33b6114ef59c9a8968f0649e6','Clauber','Maia',0,1,NULL,'pt-BR',NULL,'2018-08-14 13:15:45','2018-08-14 13:15:45','User',NULL,'only_my_events','7ac3918f48725d3cf413a72788a3790f',1,'2018-08-14 13:15:45'),(9,'mayara.guedes','602e50a806e23f86f81c0b563f3da251511dd71d','Mayara','Guedes',0,1,NULL,'pt-BR',NULL,'2018-08-14 13:16:33','2018-08-14 13:16:33','User',NULL,'only_my_events','3ef6d33d382628fda8aa689169b916f6',1,'2018-08-14 13:16:33'),(10,'rodrigo.sobral','8f76752895449da1c6d5c91464556d5cb7d636b9','Rodrigo','Sobral',0,1,NULL,'pt-BR',NULL,'2018-08-14 13:17:09','2018-08-14 13:17:09','User',NULL,'only_my_events','0a82b6e63c860143760b2f203e6ea564',1,'2018-08-14 13:17:09'),(11,'marcelo.miranda','9c2d546ec7b504ca14da239ddcb68f252941acac','Marcelo','Miranda',1,1,NULL,'pt-BR',NULL,'2018-08-14 13:17:39','2018-08-14 13:17:39','User',NULL,'only_my_events','17e1cd67adbab7ff7cff4f9f091eb526',1,'2018-08-14 13:17:39'),(12,'','','','GOVERNANÇA DE TI',0,1,NULL,'',NULL,'2018-08-15 08:13:42','2018-08-15 08:13:42','Group',NULL,'',NULL,0,NULL),(13,'luana.alves','d6a1d7c294389d0be25f1ee7ec292721458893a7','Luana','Alves',0,1,NULL,'pt-BR',NULL,'2018-08-17 08:12:44','2018-08-17 08:12:44','User',NULL,'only_my_events','3af4bff0b96072fdd1450d52a48ff0ba',0,'2018-08-17 08:12:44');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `versions`
--

DROP TABLE IF EXISTS `versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `versions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `effective_date` date DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `wiki_page_title` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT 'open',
  `sharing` varchar(255) NOT NULL DEFAULT 'none',
  PRIMARY KEY (`id`),
  KEY `versions_project_id` (`project_id`),
  KEY `index_versions_on_sharing` (`sharing`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `versions`
--

LOCK TABLES `versions` WRITE;
/*!40000 ALTER TABLE `versions` DISABLE KEYS */;
/*!40000 ALTER TABLE `versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `watchers`
--

DROP TABLE IF EXISTS `watchers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `watchers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `watchable_type` varchar(255) NOT NULL DEFAULT '',
  `watchable_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `watchers_user_id_type` (`user_id`,`watchable_type`),
  KEY `index_watchers_on_user_id` (`user_id`),
  KEY `index_watchers_on_watchable_id_and_watchable_type` (`watchable_id`,`watchable_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `watchers`
--

LOCK TABLES `watchers` WRITE;
/*!40000 ALTER TABLE `watchers` DISABLE KEYS */;
/*!40000 ALTER TABLE `watchers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_content_versions`
--

DROP TABLE IF EXISTS `wiki_content_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki_content_versions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wiki_content_id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL,
  `author_id` int(11) DEFAULT NULL,
  `data` longblob,
  `compression` varchar(6) DEFAULT '',
  `comments` varchar(1024) DEFAULT '',
  `updated_on` datetime NOT NULL,
  `version` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `wiki_content_versions_wcid` (`wiki_content_id`),
  KEY `index_wiki_content_versions_on_updated_on` (`updated_on`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki_content_versions`
--

LOCK TABLES `wiki_content_versions` WRITE;
/*!40000 ALTER TABLE `wiki_content_versions` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki_content_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_contents`
--

DROP TABLE IF EXISTS `wiki_contents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki_contents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) NOT NULL,
  `author_id` int(11) DEFAULT NULL,
  `text` longtext,
  `comments` varchar(1024) DEFAULT '',
  `updated_on` datetime NOT NULL,
  `version` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `wiki_contents_page_id` (`page_id`),
  KEY `index_wiki_contents_on_author_id` (`author_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki_contents`
--

LOCK TABLES `wiki_contents` WRITE;
/*!40000 ALTER TABLE `wiki_contents` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki_contents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_pages`
--

DROP TABLE IF EXISTS `wiki_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wiki_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `created_on` datetime NOT NULL,
  `protected` tinyint(1) NOT NULL DEFAULT '0',
  `parent_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wiki_pages_wiki_id_title` (`wiki_id`,`title`),
  KEY `index_wiki_pages_on_wiki_id` (`wiki_id`),
  KEY `index_wiki_pages_on_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki_pages`
--

LOCK TABLES `wiki_pages` WRITE;
/*!40000 ALTER TABLE `wiki_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_redirects`
--

DROP TABLE IF EXISTS `wiki_redirects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiki_redirects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wiki_id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `redirects_to` varchar(255) DEFAULT NULL,
  `created_on` datetime NOT NULL,
  `redirects_to_wiki_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `wiki_redirects_wiki_id_title` (`wiki_id`,`title`),
  KEY `index_wiki_redirects_on_wiki_id` (`wiki_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiki_redirects`
--

LOCK TABLES `wiki_redirects` WRITE;
/*!40000 ALTER TABLE `wiki_redirects` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki_redirects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wikis`
--

DROP TABLE IF EXISTS `wikis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wikis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `start_page` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `wikis_project_id` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wikis`
--

LOCK TABLES `wikis` WRITE;
/*!40000 ALTER TABLE `wikis` DISABLE KEYS */;
INSERT INTO `wikis` VALUES (1,1,'Wiki',1),(2,3,'Wiki',1);
/*!40000 ALTER TABLE `wikis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflows`
--

DROP TABLE IF EXISTS `workflows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tracker_id` int(11) NOT NULL DEFAULT '0',
  `old_status_id` int(11) NOT NULL DEFAULT '0',
  `new_status_id` int(11) NOT NULL DEFAULT '0',
  `role_id` int(11) NOT NULL DEFAULT '0',
  `assignee` tinyint(1) NOT NULL DEFAULT '0',
  `author` tinyint(1) NOT NULL DEFAULT '0',
  `type` varchar(30) DEFAULT NULL,
  `field_name` varchar(30) DEFAULT NULL,
  `rule` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wkfs_role_tracker_old_status` (`role_id`,`tracker_id`,`old_status_id`),
  KEY `index_workflows_on_old_status_id` (`old_status_id`),
  KEY `index_workflows_on_role_id` (`role_id`),
  KEY `index_workflows_on_new_status_id` (`new_status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflows`
--

LOCK TABLES `workflows` WRITE;
/*!40000 ALTER TABLE `workflows` DISABLE KEYS */;
INSERT INTO `workflows` VALUES (1,1,1,2,3,0,0,'WorkflowTransition',NULL,NULL),(2,1,1,3,3,0,0,'WorkflowTransition',NULL,NULL),(3,1,1,4,3,0,0,'WorkflowTransition',NULL,NULL),(4,1,1,5,3,0,0,'WorkflowTransition',NULL,NULL),(5,1,1,6,3,0,0,'WorkflowTransition',NULL,NULL),(6,1,2,1,3,0,0,'WorkflowTransition',NULL,NULL),(7,1,2,3,3,0,0,'WorkflowTransition',NULL,NULL),(8,1,2,4,3,0,0,'WorkflowTransition',NULL,NULL),(9,1,2,5,3,0,0,'WorkflowTransition',NULL,NULL),(10,1,2,6,3,0,0,'WorkflowTransition',NULL,NULL),(11,1,3,1,3,0,0,'WorkflowTransition',NULL,NULL),(12,1,3,2,3,0,0,'WorkflowTransition',NULL,NULL),(13,1,3,4,3,0,0,'WorkflowTransition',NULL,NULL),(14,1,3,5,3,0,0,'WorkflowTransition',NULL,NULL),(15,1,3,6,3,0,0,'WorkflowTransition',NULL,NULL),(16,1,4,1,3,0,0,'WorkflowTransition',NULL,NULL),(17,1,4,2,3,0,0,'WorkflowTransition',NULL,NULL),(18,1,4,3,3,0,0,'WorkflowTransition',NULL,NULL),(19,1,4,5,3,0,0,'WorkflowTransition',NULL,NULL),(20,1,4,6,3,0,0,'WorkflowTransition',NULL,NULL),(21,1,5,1,3,0,0,'WorkflowTransition',NULL,NULL),(22,1,5,2,3,0,0,'WorkflowTransition',NULL,NULL),(23,1,5,3,3,0,0,'WorkflowTransition',NULL,NULL),(24,1,5,4,3,0,0,'WorkflowTransition',NULL,NULL),(25,1,5,6,3,0,0,'WorkflowTransition',NULL,NULL),(26,1,6,1,3,0,0,'WorkflowTransition',NULL,NULL),(27,1,6,2,3,0,0,'WorkflowTransition',NULL,NULL),(28,1,6,3,3,0,0,'WorkflowTransition',NULL,NULL),(29,1,6,4,3,0,0,'WorkflowTransition',NULL,NULL),(30,1,6,5,3,0,0,'WorkflowTransition',NULL,NULL),(31,2,1,2,3,0,0,'WorkflowTransition',NULL,NULL),(32,2,1,3,3,0,0,'WorkflowTransition',NULL,NULL),(33,2,1,4,3,0,0,'WorkflowTransition',NULL,NULL),(34,2,1,5,3,0,0,'WorkflowTransition',NULL,NULL),(35,2,1,6,3,0,0,'WorkflowTransition',NULL,NULL),(36,2,2,1,3,0,0,'WorkflowTransition',NULL,NULL),(37,2,2,3,3,0,0,'WorkflowTransition',NULL,NULL),(38,2,2,4,3,0,0,'WorkflowTransition',NULL,NULL),(39,2,2,5,3,0,0,'WorkflowTransition',NULL,NULL),(40,2,2,6,3,0,0,'WorkflowTransition',NULL,NULL),(41,2,3,1,3,0,0,'WorkflowTransition',NULL,NULL),(42,2,3,2,3,0,0,'WorkflowTransition',NULL,NULL),(43,2,3,4,3,0,0,'WorkflowTransition',NULL,NULL),(44,2,3,5,3,0,0,'WorkflowTransition',NULL,NULL),(45,2,3,6,3,0,0,'WorkflowTransition',NULL,NULL),(46,2,4,1,3,0,0,'WorkflowTransition',NULL,NULL),(47,2,4,2,3,0,0,'WorkflowTransition',NULL,NULL),(48,2,4,3,3,0,0,'WorkflowTransition',NULL,NULL),(49,2,4,5,3,0,0,'WorkflowTransition',NULL,NULL),(50,2,4,6,3,0,0,'WorkflowTransition',NULL,NULL),(51,2,5,1,3,0,0,'WorkflowTransition',NULL,NULL),(52,2,5,2,3,0,0,'WorkflowTransition',NULL,NULL),(53,2,5,3,3,0,0,'WorkflowTransition',NULL,NULL),(54,2,5,4,3,0,0,'WorkflowTransition',NULL,NULL),(55,2,5,6,3,0,0,'WorkflowTransition',NULL,NULL),(56,2,6,1,3,0,0,'WorkflowTransition',NULL,NULL),(57,2,6,2,3,0,0,'WorkflowTransition',NULL,NULL),(58,2,6,3,3,0,0,'WorkflowTransition',NULL,NULL),(59,2,6,4,3,0,0,'WorkflowTransition',NULL,NULL),(60,2,6,5,3,0,0,'WorkflowTransition',NULL,NULL),(61,3,1,2,3,0,0,'WorkflowTransition',NULL,NULL),(62,3,1,3,3,0,0,'WorkflowTransition',NULL,NULL),(63,3,1,4,3,0,0,'WorkflowTransition',NULL,NULL),(64,3,1,5,3,0,0,'WorkflowTransition',NULL,NULL),(65,3,1,6,3,0,0,'WorkflowTransition',NULL,NULL),(66,3,2,1,3,0,0,'WorkflowTransition',NULL,NULL),(67,3,2,3,3,0,0,'WorkflowTransition',NULL,NULL),(68,3,2,4,3,0,0,'WorkflowTransition',NULL,NULL),(69,3,2,5,3,0,0,'WorkflowTransition',NULL,NULL),(70,3,2,6,3,0,0,'WorkflowTransition',NULL,NULL),(71,3,3,1,3,0,0,'WorkflowTransition',NULL,NULL),(72,3,3,2,3,0,0,'WorkflowTransition',NULL,NULL),(73,3,3,4,3,0,0,'WorkflowTransition',NULL,NULL),(74,3,3,5,3,0,0,'WorkflowTransition',NULL,NULL),(75,3,3,6,3,0,0,'WorkflowTransition',NULL,NULL),(76,3,4,1,3,0,0,'WorkflowTransition',NULL,NULL),(77,3,4,2,3,0,0,'WorkflowTransition',NULL,NULL),(78,3,4,3,3,0,0,'WorkflowTransition',NULL,NULL),(79,3,4,5,3,0,0,'WorkflowTransition',NULL,NULL),(80,3,4,6,3,0,0,'WorkflowTransition',NULL,NULL),(81,3,5,1,3,0,0,'WorkflowTransition',NULL,NULL),(82,3,5,2,3,0,0,'WorkflowTransition',NULL,NULL),(83,3,5,3,3,0,0,'WorkflowTransition',NULL,NULL),(84,3,5,4,3,0,0,'WorkflowTransition',NULL,NULL),(85,3,5,6,3,0,0,'WorkflowTransition',NULL,NULL),(86,3,6,1,3,0,0,'WorkflowTransition',NULL,NULL),(87,3,6,2,3,0,0,'WorkflowTransition',NULL,NULL),(88,3,6,3,3,0,0,'WorkflowTransition',NULL,NULL),(89,3,6,4,3,0,0,'WorkflowTransition',NULL,NULL),(90,3,6,5,3,0,0,'WorkflowTransition',NULL,NULL),(91,1,1,2,4,0,0,'WorkflowTransition',NULL,NULL),(92,1,1,3,4,0,0,'WorkflowTransition',NULL,NULL),(93,1,1,4,4,0,0,'WorkflowTransition',NULL,NULL),(94,1,1,5,4,0,0,'WorkflowTransition',NULL,NULL),(95,1,2,3,4,0,0,'WorkflowTransition',NULL,NULL),(96,1,2,4,4,0,0,'WorkflowTransition',NULL,NULL),(97,1,2,5,4,0,0,'WorkflowTransition',NULL,NULL),(98,1,3,2,4,0,0,'WorkflowTransition',NULL,NULL),(99,1,3,4,4,0,0,'WorkflowTransition',NULL,NULL),(100,1,3,5,4,0,0,'WorkflowTransition',NULL,NULL),(101,1,4,2,4,0,0,'WorkflowTransition',NULL,NULL),(102,1,4,3,4,0,0,'WorkflowTransition',NULL,NULL),(103,1,4,5,4,0,0,'WorkflowTransition',NULL,NULL),(104,2,1,2,4,0,0,'WorkflowTransition',NULL,NULL),(105,2,1,3,4,0,0,'WorkflowTransition',NULL,NULL),(106,2,1,4,4,0,0,'WorkflowTransition',NULL,NULL),(107,2,1,5,4,0,0,'WorkflowTransition',NULL,NULL),(108,2,2,3,4,0,0,'WorkflowTransition',NULL,NULL),(109,2,2,4,4,0,0,'WorkflowTransition',NULL,NULL),(110,2,2,5,4,0,0,'WorkflowTransition',NULL,NULL),(111,2,3,2,4,0,0,'WorkflowTransition',NULL,NULL),(112,2,3,4,4,0,0,'WorkflowTransition',NULL,NULL),(113,2,3,5,4,0,0,'WorkflowTransition',NULL,NULL),(114,2,4,2,4,0,0,'WorkflowTransition',NULL,NULL),(115,2,4,3,4,0,0,'WorkflowTransition',NULL,NULL),(116,2,4,5,4,0,0,'WorkflowTransition',NULL,NULL),(117,3,1,2,4,0,0,'WorkflowTransition',NULL,NULL),(118,3,1,3,4,0,0,'WorkflowTransition',NULL,NULL),(119,3,1,4,4,0,0,'WorkflowTransition',NULL,NULL),(120,3,1,5,4,0,0,'WorkflowTransition',NULL,NULL),(121,3,2,3,4,0,0,'WorkflowTransition',NULL,NULL),(122,3,2,4,4,0,0,'WorkflowTransition',NULL,NULL),(123,3,2,5,4,0,0,'WorkflowTransition',NULL,NULL),(124,3,3,2,4,0,0,'WorkflowTransition',NULL,NULL),(125,3,3,4,4,0,0,'WorkflowTransition',NULL,NULL),(126,3,3,5,4,0,0,'WorkflowTransition',NULL,NULL),(127,3,4,2,4,0,0,'WorkflowTransition',NULL,NULL),(128,3,4,3,4,0,0,'WorkflowTransition',NULL,NULL),(129,3,4,5,4,0,0,'WorkflowTransition',NULL,NULL),(130,1,1,5,5,0,0,'WorkflowTransition',NULL,NULL),(131,1,2,5,5,0,0,'WorkflowTransition',NULL,NULL),(132,1,3,5,5,0,0,'WorkflowTransition',NULL,NULL),(133,1,4,5,5,0,0,'WorkflowTransition',NULL,NULL),(134,1,3,4,5,0,0,'WorkflowTransition',NULL,NULL),(135,2,1,5,5,0,0,'WorkflowTransition',NULL,NULL),(136,2,2,5,5,0,0,'WorkflowTransition',NULL,NULL),(137,2,3,5,5,0,0,'WorkflowTransition',NULL,NULL),(138,2,4,5,5,0,0,'WorkflowTransition',NULL,NULL),(139,2,3,4,5,0,0,'WorkflowTransition',NULL,NULL),(140,3,1,5,5,0,0,'WorkflowTransition',NULL,NULL),(141,3,2,5,5,0,0,'WorkflowTransition',NULL,NULL),(142,3,3,5,5,0,0,'WorkflowTransition',NULL,NULL),(143,3,4,5,5,0,0,'WorkflowTransition',NULL,NULL),(144,3,3,4,5,0,0,'WorkflowTransition',NULL,NULL);
/*!40000 ALTER TABLE `workflows` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-16 23:51:02
